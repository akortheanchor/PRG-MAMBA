"""
Blockchain Audit Layer
=======================
Implements Section 5.6, Eq. (25):
  B_k = H(D_k || B_{k-1})

Provides per-inference SHA-256 tamper-evident records
under PBFT consensus (Theorem 1, Section 5.6.3).

Security guarantee (Theorem 1):
  Pr[undetected] ≤ 2^{-256} + ε_PBFT(b)
  where b=4 validators, ε_PBFT(4) is negligible.

Storage: 32-byte on-chain hash vs 12KB raw BVP
  → 99.7% reduction at 10.5% inference overhead.

Paper reference: PRG-Mamba, Section 5.6
"""

import hashlib
import json
import time
from typing import Dict, List, Optional
import numpy as np


class BlockchainAudit:
    """
    SHA-256 hash-chaining audit layer for rPPG predictions.

    Maintains an in-process blockchain of prediction records.
    In production, block hashes are committed to a PBFT
    permissioned ledger (4 validators, Table 6).

    This class implements:
      - Block creation (Eq. 25): B_k = H(D_k || B_{k-1})
      - Audit verification (Definition 3, Appendix B.5)
      - Tamper detection (Theorem 1, Section 5.6.3)

    Args:
        genesis_hash: Hash of the genesis block (B_0)
        store_raw:    If True, store raw BVP in block (dev mode only)
    """

    GENESIS_HASH = "0" * 64   # B_0: all-zero SHA-256 hash

    def __init__(
        self,
        genesis_hash: str = GENESIS_HASH,
        store_raw: bool = False,
    ):
        self.chain: List[Dict] = []
        self.prev_hash  = genesis_hash
        self.store_raw  = store_raw
        self.block_count = 0

    def _sha256(self, data: str) -> str:
        """Compute SHA-256 hash of a UTF-8 string (Definition 1)."""
        return hashlib.sha256(data.encode('utf-8')).hexdigest()

    def _serialise(self, D_k: Dict) -> str:
        """
        Serialise prediction tuple D_k to canonical JSON string.
        Ensures byte-for-byte reproducibility for hash computation.
        """
        return json.dumps(D_k, sort_keys=True, separators=(',', ':'))

    def commit(
        self,
        bvp_signal: np.ndarray,
        hr_pred: float,
        metadata: Optional[Dict] = None,
    ) -> Dict:
        """
        Commit one inference prediction to the audit chain.

        Implements Eq. (25): B_k = H(D_k || B_{k-1})

        D_k = {bvp_hash, hr_pred, timestamp, block_index,
               device_id, model_version}

        Only the 32-byte SHA-256 digest is stored on-chain.
        Raw BVP (12KB) is stored off-chain and linked by hash.

        Args:
            bvp_signal: (T,) predicted BVP numpy array
            hr_pred:    Predicted HR in bpm
            metadata:   Optional dict with device_id, model_version, etc.

        Returns:
            block: Dict representing block B_k
        """
        # Hash the raw BVP signal (off-chain reference)
        bvp_bytes = bvp_signal.astype(np.float32).tobytes()
        bvp_hash  = hashlib.sha256(bvp_bytes).hexdigest()

        # Assemble prediction tuple D_k
        meta  = metadata or {}
        D_k = {
            'block_index'   : self.block_count,
            'timestamp'     : time.time(),
            'bvp_hash'      : bvp_hash,       # reference to off-chain BVP
            'hr_pred_bpm'   : round(float(hr_pred), 4),
            'device_id'     : meta.get('device_id',     'unknown'),
            'model_version' : meta.get('model_version', 'prgmamba-v1.0'),
            'env'           : meta.get('env',            'inference'),
        }

        # Optionally store raw BVP for development auditing
        if self.store_raw:
            D_k['bvp_raw'] = bvp_signal.tolist()

        # Eq. (25): B_k = H(D_k || B_{k-1})
        block_data = self._serialise(D_k) + self.prev_hash
        block_hash = self._sha256(block_data)

        block = {
            **D_k,
            'prev_hash'  : self.prev_hash,
            'block_hash' : block_hash,
        }

        self.chain.append(block)
        self.prev_hash  = block_hash
        self.block_count += 1

        return block

    def verify(self) -> Dict:
        """
        Verify the integrity of the entire audit chain.

        Implements the Audit Verifier V (Definition 3, Appendix B.5).
        Checks four conditions:
          (i)   hash consistency: B_k = H(D_k || B_{k-1})
          (ii)  timestamp monotonicity: t_k > t_{k-1}
          (iii) sequence integrity: block indices are consecutive
          (iv)  no missing blocks

        Returns:
            Dict with keys: valid, num_blocks, first_tamper_idx, report
        """
        if not self.chain:
            return {'valid': True, 'num_blocks': 0, 'report': 'Empty chain'}

        prev = self.GENESIS_HASH
        errors = []

        for k, block in enumerate(self.chain):
            # Reconstruct D_k (exclude prev_hash and block_hash)
            D_k = {
                key: val for key, val in block.items()
                if key not in ('prev_hash', 'block_hash')
            }

            # Check (i): hash consistency
            expected_data  = self._serialise(D_k) + prev
            expected_hash  = self._sha256(expected_data)
            if expected_hash != block['block_hash']:
                errors.append({
                    'block': k,
                    'type' : 'hash_mismatch',
                    'msg'  : f"Block {k}: hash mismatch — TAMPERED"
                })

            # Check (ii): timestamp monotonicity
            if k > 0:
                if block['timestamp'] <= self.chain[k-1]['timestamp']:
                    errors.append({
                        'block': k,
                        'type' : 'timestamp_violation',
                        'msg'  : f"Block {k}: timestamp not monotone"
                    })

            # Check (iii): sequence integrity
            if block['block_index'] != k:
                errors.append({
                    'block': k,
                    'type' : 'sequence_violation',
                    'msg'  : f"Block {k}: index mismatch {block['block_index']}"
                })

            prev = block['block_hash']

        valid     = len(errors) == 0
        tamper_at = errors[0]['block'] if errors else None

        return {
            'valid'           : valid,
            'num_blocks'      : len(self.chain),
            'first_tamper_idx': tamper_at,
            'num_errors'      : len(errors),
            'errors'          : errors,
            'report'          : 'Chain intact' if valid else f'{len(errors)} violation(s) detected',
        }

    def tamper_block(self, idx: int, new_hr: float) -> None:
        """
        Controlled tampering for evaluation (Table blockchain_eval).
        Modifies block idx's hr_pred without updating the hash chain.
        Used to validate 100% tamper detection (Section 6.7).
        """
        if 0 <= idx < len(self.chain):
            self.chain[idx]['hr_pred_bpm'] = new_hr

    def export_chain(self) -> List[Dict]:
        """Export the full audit chain for off-chain storage."""
        return list(self.chain)

    def __len__(self):
        return self.block_count

    def __repr__(self):
        return (
            f"BlockchainAudit("
            f"blocks={self.block_count}, "
            f"prev_hash={self.prev_hash[:16]}...)"
        )
