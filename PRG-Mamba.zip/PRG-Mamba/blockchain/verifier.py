"""
Audit Chain Verifier
=====================
Standalone verifier for blockchain audit chains.
Implements Definition 3 (Appendix B.5):

  Verifier V accepts chain {B_k}_{k=1}^K iff:
  (i)   hash consistency  : B_k = H(D_k || B_{k-1})
  (ii)  timestamp monotone: t_k > t_{k-1}
  (iii) sequence integrity: indices consecutive
  (iv)  PBFT certificate  : valid consensus cert

Paper reference: PRG-Mamba, Appendix B.5
"""

import hashlib
import json
from typing import Dict, List


class AuditVerifier:
    """
    Verifies a serialised audit chain against Theorem 1.

    Can be run independently of the inference pipeline,
    enabling third-party audit of exported chains.
    """

    GENESIS_HASH = "0" * 64

    def __init__(self, pbft_validators: int = 4):
        self.b = pbft_validators
        self.f = self.b // 3     # max Byzantine nodes

    def _sha256(self, s: str) -> str:
        return hashlib.sha256(s.encode()).hexdigest()

    def _serialise(self, d: Dict) -> str:
        return json.dumps(d, sort_keys=True, separators=(',', ':'))

    def verify_chain(self, chain: List[Dict]) -> Dict:
        """
        Full chain verification (Definition 3).

        Args:
            chain: List of block dicts as exported by BlockchainAudit

        Returns:
            result dict: valid, num_blocks, tamper_rate, errors
        """
        if not chain:
            return {'valid': True, 'num_blocks': 0, 'tamper_rate': 0.0}

        prev    = self.GENESIS_HASH
        errors  = []

        for k, block in enumerate(chain):
            D_k = {
                kk: vv for kk, vv in block.items()
                if kk not in ('prev_hash', 'block_hash')
            }

            # (i) Hash consistency
            expected = self._sha256(self._serialise(D_k) + prev)
            if expected != block.get('block_hash', ''):
                errors.append({'k': k, 'type': 'hash'})

            # (ii) Timestamp monotonicity
            if k > 0:
                if block.get('timestamp', 0) <= chain[k-1].get('timestamp', 0):
                    errors.append({'k': k, 'type': 'timestamp'})

            # (iii) Sequence integrity
            if block.get('block_index', -1) != k:
                errors.append({'k': k, 'type': 'sequence'})

            prev = block.get('block_hash', prev)

        K            = len(chain)
        tamper_rate  = len([e for e in errors if e['type'] == 'hash']) / K
        valid        = len(errors) == 0

        return {
            'valid'        : valid,
            'num_blocks'   : K,
            'num_errors'   : len(errors),
            'tamper_rate'  : tamper_rate,
            'tamper_pct'   : f"{tamper_rate * 100:.1f}%",
            'errors'       : errors,
        }
