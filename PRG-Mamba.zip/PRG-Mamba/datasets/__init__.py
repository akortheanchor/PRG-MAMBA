"""Dataset Registry — maps dataset name strings to loader classes."""

from datasets.pure         import PUREDataset
from datasets.base_dataset import BaseRPPGDataset

DATASET_REGISTRY = {
    'PURE'      : PUREDataset,
    'UBFC-RPPG' : None,
    'MMPD'      : None,
    'VIPL-HR'   : None,
    'IBVP'      : None,
    'SCAMPS'    : None,
    'OBF'       : None,
}

def get_dataset_class(name: str):
    key = name.upper()
    if key not in DATASET_REGISTRY:
        raise KeyError(f"Dataset '{name}' not in registry.")
    cls = DATASET_REGISTRY[key]
    if cls is None:
        raise NotImplementedError(
            f"Loader for '{name}' not yet implemented. "
            f"Follow datasets/pure.py template."
        )
    return cls
