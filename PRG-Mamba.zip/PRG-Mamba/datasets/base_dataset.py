"""
Abstract Base Dataset Class
============================
Defines the interface for all seven benchmark datasets.
Implements subject-level splits (Section 6.1, Table 3)
and clip-level windowing (Section 5.7).

All subclasses must implement:
  _load_subjects()   — populate self.subjects list
  _load_clip()       — load one (clip, bvp, hr) tuple

Paper reference: PRG-Mamba, Sections 6.1, 5.7
"""

import os
import numpy as np
import torch
from torch.utils.data import Dataset
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Tuple
from omegaconf import DictConfig


class BaseRPPGDataset(Dataset, ABC):
    """
    Abstract base class for all rPPG benchmark datasets.

    Provides:
      - Subject-level train/val/test splitting (prevents data leakage)
      - Sliding window clip extraction (T=128, step=64)
      - OctaAug integration hook
      - HR label computation from BVP ground truth

    Args:
        cfg:      Dataset config block
        split:    'train', 'val', or 'test'
        augment:  If True, apply OctaAug during __getitem__
        octaaug:  OctaAug pipeline instance (optional)
    """

    SPLIT_RATIOS = {'80_10_10': (0.8, 0.1, 0.1)}

    def __init__(
        self,
        cfg: DictConfig,
        split: str = 'train',
        augment: bool = True,
        octaaug=None,
    ):
        super().__init__()
        self.cfg     = cfg
        self.split   = split
        self.augment = augment
        self.oa      = octaaug
        self.T       = getattr(cfg, 'clip_len', 128)
        self.step    = getattr(cfg, 'clip_step', 64)
        self.fs      = getattr(cfg, 'fps', 30)
        self.H = self.W = getattr(cfg, 'img_size', 128)

        self.clips: List[Dict] = []   # list of {path, bvp, hr, subject}

        # Load all subjects, then split
        all_subjects = self._load_subjects()
        self.subject_ids = self._split_subjects(all_subjects, split, cfg)

        # Build clip index
        for sid in self.subject_ids:
            self.clips.extend(self._index_clips(sid))

        print(f"  {self.__class__.__name__} [{split}]: "
              f"{len(self.subject_ids)} subjects, "
              f"{len(self.clips)} clips")

    @abstractmethod
    def _load_subjects(self) -> List[str]:
        """Return list of all subject IDs in the dataset."""
        ...

    @abstractmethod
    def _load_clip(self, clip_info: Dict) -> Tuple[np.ndarray, np.ndarray, float]:
        """
        Load one video clip and its labels.

        Args:
            clip_info: dict with path information

        Returns:
            clip:  (T, H, W, 3) uint8 RGB frames
            bvp:   (T,) float32 BVP ground-truth signal
            hr_gt: float ground-truth HR in bpm
        """
        ...

    @abstractmethod
    def _index_clips(self, subject_id: str) -> List[Dict]:
        """
        Build list of clip_info dicts for a given subject.
        Each dict must contain all information needed by _load_clip.
        """
        ...

    def _split_subjects(
        self,
        all_subjects: List[str],
        split: str,
        cfg: DictConfig
    ) -> List[str]:
        """
        Split subjects by split_type (loso or 80_10_10 or official).

        Subject-level splits prevent data leakage (Section 6.1,
        Section 7.5.2).
        """
        split_type = getattr(cfg, 'split_type', '80_10_10')

        if split_type == 'loso':
            # PURE: each subject is test fold once (leave-one-subject-out)
            n = len(all_subjects)
            fold_map = {s: i % n for i, s in enumerate(all_subjects)}
            if split == 'test':
                return all_subjects   # all subjects appear in test (LOSO)
            return all_subjects       # train on n-1, test on 1

        elif split_type == 'official':
            # MMPD, VIPL-HR, SCAMPS: use dataset-provided splits
            return self._load_official_split(split)

        else:  # 80_10_10
            n        = len(all_subjects)
            rng      = np.random.RandomState(42)
            perm     = rng.permutation(n)
            n_train  = int(n * 0.80)
            n_val    = int(n * 0.10)
            if split == 'train':
                idx = perm[:n_train]
            elif split == 'val':
                idx = perm[n_train:n_train + n_val]
            else:
                idx = perm[n_train + n_val:]
            return [all_subjects[i] for i in idx]

    def _load_official_split(self, split: str) -> List[str]:
        """
        Load subjects from dataset-provided split files.
        Subclasses override if official splits use different naming.
        """
        split_file = os.path.join(
            self.cfg.data_root, f'{split}_subjects.txt'
        )
        if os.path.exists(split_file):
            with open(split_file) as f:
                return [line.strip() for line in f if line.strip()]
        return []

    def __len__(self) -> int:
        return len(self.clips)

    def __getitem__(self, idx: int) -> Dict:
        """
        Load one clip and optionally apply OctaAug.

        Returns dict with keys:
          clip:      (3, T, H, W) float32 normalised frames
          bvp:       (T,) float32 BVP label
          hr:        float HR label (bpm)
          subject:   str subject ID
          fps_eff:   float effective fps after TRR
          delta_trr: int TRR-recalibrated lag
        """
        info      = self.clips[idx]
        clip, bvp, hr_gt = self._load_clip(info)

        fps_eff   = float(self.fs)
        delta_trr = int(round(self.fs * 60.0 / max(hr_gt, 40.0)))

        if self.augment and self.oa is not None:
            # Fetch a second clip for TCM mixing
            idx2     = np.random.randint(len(self.clips))
            info2    = self.clips[idx2]
            clip2, bvp2, hr2 = self._load_clip(info2)

            result   = self.oa(
                clip, bvp, hr_gt,
                epoch=getattr(self, '_epoch', 2),
                clip2=clip2, bvp2=bvp2,
                training=True,
            )
            bvp      = result['bvp']
            hr_gt    = result['hr']
            fps_eff  = result['fps_eff']
            delta_trr = result['delta_trr']
            # Fuse streams to tensor
            streams  = result['streams']
            clip_t   = self.oa.fuse_streams(
                streams, self.T, self.H, self.W
            )
        else:
            # No augmentation: simple normalise
            clip_f   = clip.astype(np.float32) / 255.0
            clip_t   = torch.from_numpy(
                clip_f.transpose(3, 0, 1, 2)
            ).float()            # (3, T, H, W)

        return {
            'clip'      : clip_t,
            'bvp'       : torch.from_numpy(bvp).float(),
            'hr'        : torch.tensor(hr_gt, dtype=torch.float32),
            'subject'   : info.get('subject', ''),
            'fps_eff'   : fps_eff,
            'delta_trr' : delta_trr,
        }

    def set_epoch(self, epoch: int):
        """Update current epoch for PBSM epoch-1 disable logic."""
        self._epoch = epoch
