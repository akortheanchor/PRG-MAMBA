"""
PURE Dataset Loader
====================
Implements the PURE dataset (10 subjects, 60 clips) with:
  - Leave-one-subject-out (LOSO) split protocol
  - Six head-movement protocols per subject
  - JSON-format BVP ground truth

Dataset reference:
  Stricker, R., Müller, S., & Gross, H.M. (2014). Non-contact video-based
  pulse rate measurement on a mobile service robot. ROMAN 2014.

Paper split: LOSO — all subjects appear in test exactly once (Section 6.1)
"""

import os
import json
import glob
import cv2
import numpy as np
from typing import Dict, List, Tuple
from omegaconf import DictConfig

from datasets.base_dataset import BaseRPPGDataset


PURE_ACTIVITIES = {
    '01': 'stationary',
    '02': 'talking',
    '03': 'slow_translation',
    '04': 'fast_translation',
    '05': 'small_rotation',
    '06': 'large_rotation',
}


class PUREDataset(BaseRPPGDataset):
    """
    PURE rPPG dataset loader.

    Directory structure expected (from docs/DATASETS.md):
      data/PURE/
        01-01/  01-02/  ...  10-06/
          *.png       (video frames, sorted by filename)
          *.json      (BVP + HR ground truth)
    """

    def _load_subjects(self) -> List[str]:
        """Return list of all 10 subject IDs ('01' ... '10')."""
        data_root = self.cfg.data_root
        subjects  = sorted(set(
            d.split('-')[0]
            for d in os.listdir(data_root)
            if os.path.isdir(os.path.join(data_root, d))
            and '-' in d
        ))
        return subjects

    def _index_clips(self, subject_id: str) -> List[Dict]:
        """Build clip info list for one subject (6 clips)."""
        data_root = self.cfg.data_root
        clips     = []
        for act_code in ['01', '02', '03', '04', '05', '06']:
            clip_dir = os.path.join(data_root, f'{subject_id}-{act_code}')
            if not os.path.isdir(clip_dir):
                continue
            # Find JSON ground-truth file
            json_files = glob.glob(os.path.join(clip_dir, '*.json'))
            if not json_files:
                continue
            clips.append({
                'subject'  : subject_id,
                'activity' : PURE_ACTIVITIES.get(act_code, 'unknown'),
                'clip_dir' : clip_dir,
                'gt_json'  : json_files[0],
            })
        return clips

    def _load_clip(self, info: Dict) -> Tuple[np.ndarray, np.ndarray, float]:
        """
        Load one PURE clip.

        Returns:
            clip:  (T, H, W, 3) uint8 RGB frames
            bvp:   (T,) float32 normalised BVP signal
            hr_gt: float ground-truth HR in bpm
        """
        clip_dir = info['clip_dir']
        gt_json  = info['gt_json']

        # Load ground-truth JSON
        with open(gt_json) as f:
            gt_data = json.load(f)

        # Extract BVP and HR
        # PURE JSON format: {'/FullPackage': [{..., 'Value': {'waveform': float}}]}
        waveforms = []
        hr_values = []
        for entry in gt_data.get('/FullPackage', []):
            v = entry.get('Value', {})
            if 'waveform' in v:
                waveforms.append(float(v['waveform']))
            if 'pulseRate' in v:
                hr_values.append(float(v['pulseRate']))

        # Load frames (sorted PNG files)
        frame_files = sorted(glob.glob(os.path.join(clip_dir, '*.png')))
        if not frame_files:
            raise FileNotFoundError(f"No PNG frames in {clip_dir}")

        # Align frame count with BVP
        T_bvp    = len(waveforms) if waveforms else len(frame_files)
        T_frames = min(len(frame_files), T_bvp)
        T_use    = min(T_frames, self.T * 3)  # cap at 3x clip length

        frames = []
        for fpath in frame_files[:T_use]:
            img = cv2.imread(fpath)
            if img is None:
                continue
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            img = cv2.resize(img, (self.W, self.H))
            frames.append(img)

        if not frames:
            raise RuntimeError(f"Could not load frames from {clip_dir}")

        frames = np.stack(frames, axis=0)    # (T_use, H, W, 3)

        # Align BVP to frame count
        bvp = np.array(waveforms[:len(frames)], dtype=np.float32)
        if len(bvp) < len(frames):
            bvp = np.pad(bvp, (0, len(frames) - len(bvp)), mode='edge')

        # Normalise BVP
        bvp = (bvp - bvp.mean()) / (bvp.std() + 1e-8)

        # Ground-truth HR (mean of valid pulse rate readings)
        hr_gt = float(np.mean(hr_values)) if hr_values else 75.0
        hr_gt = np.clip(hr_gt, 40.0, 200.0)

        # Extract T-frame window from centre of clip
        if len(frames) >= self.T:
            start  = (len(frames) - self.T) // 2
            frames = frames[start:start + self.T]
            bvp    = bvp[start:start + self.T]
        else:
            # Pad if clip shorter than T
            pad    = self.T - len(frames)
            frames = np.pad(frames, ((0, pad), (0, 0), (0, 0), (0, 0)),
                           mode='edge')
            bvp    = np.pad(bvp, (0, pad), mode='edge')

        return frames, bvp, hr_gt
