# Dataset Setup Guide

This document describes how to download, organise, and preprocess all
seven benchmark datasets used in PRG-Mamba.

---

## Expected Directory Structure

```
data/
├── PURE/
│   ├── 01-01/  01-02/  ...  10-06/
│   │   ├── *.png           (video frames)
│   │   └── *.json          (BVP + HR ground truth)
├── UBFC-rPPG/
│   ├── subject1/  ...  subject42/
│   │   ├── vid.avi
│   │   └── ground_truth.txt
├── MMPD/
│   ├── subject1/  ...  subject33/
│   │   └── p{i}_{activity}_{light}.mat
├── VIPL-HR/
│   ├── data/
│   │   └── p{i}/v{j}/source{k}/
│   │       ├── video.avi
│   │       └── gt_HR.csv
├── iBVP/
│   ├── p01_a/  p01_b/  ...  p31_x/
│   │   ├── pXX_x_rgb/      (RGB frames)
│   │   ├── pXX_x_t/        (Thermal frames)
│   │   └── pXX_x_bvp.csv
├── SCAMPS/
│   ├── Videos_RGB/
│   │   └── *.avi
│   └── Labels/
│       └── *.mat
└── OBF/
    ├── subject{i}/
    │   ├── *.avi
    │   └── ECG.mat
```

---

## Download Links

| Dataset | URL | Access |
|---------|-----|--------|
| PURE | https://www.tu-ilmenau.de/...PURE | Free registration |
| UBFC-rPPG | https://sites.google.com/view/ybenezeth/ubfcrppg | Free |
| MMPD | https://github.com/McJackTang/MMPD_rPPG_dataset | Free |
| VIPL-HR | http://vipl.ict.ac.cn/en/view_database.php?id=15 | Free registration |
| iBVP | https://github.com/PhysiologicalSignalProcessing/iBVP | Free |
| SCAMPS | https://github.com/danmcduff/scampsdataset | Free |
| OBF | Contact dataset authors | On request |

---

## Preprocessing

Run the unified preprocessor:

```bash
python scripts/preprocess.py \
    --dataset all \
    --data_root /path/to/data \
    --output_root /path/to/processed \
    --img_size 128 \
    --clip_len 128 \
    --clip_step 64
```

For a single dataset:

```bash
python scripts/preprocess.py --dataset MMPD --data_root /path/to/data/MMPD
```

### What preprocessing does

1. **Face detection**: RetinaFace detects and crops facial ROI
2. **Resize**: All frames resized to 128×128 pixels
3. **BVP extraction**: Ground-truth BVP normalised to zero mean, unit std
4. **HR computation**: HR extracted from BVP via spectral peak detection
5. **Windowing**: Clips extracted with T=128 frames, step=64 frames
6. **Split files**: Subject-level train/val/test splits written to `{dataset}/splits/`

---

## Dataset Statistics

| Dataset | n_subjects | n_clips | HR range | fs | Skin tones | Challenge |
|---------|-----------|---------|----------|-----|------------|-----------|
| PURE | 10 | 60 | 55-115 | 30 | I-III | Head movements |
| UBFC-rPPG | 42 | 84 | 62-120 | 30 | I-III | Mental arithmetic |
| MMPD | 33 | 264 | 52-138 | 30 | I-VI | Mobile, walking |
| VIPL-HR | 107 | 428 | 48-150 | 25 | I-VI | Wild, multi-device |
| iBVP | 31 | 93 | 58-125 | 30 | II-V | RGB + Thermal |
| SCAMPS | 2800 | 2800 | 40-180 | 30 | I-VI | Synthetic |
| OBF | 100 | 200 | 45-120 | 60 | II-V | 60fps, ECG GT |

---

## Split Protocols

| Dataset | Protocol | Reference |
|---------|----------|-----------|
| PURE | LOSO (leave-one-subject-out) | Section 6.1 |
| UBFC-rPPG | 80/10/10 subject-level | Section 6.1 |
| MMPD | Official split (Tang et al. 2023) | Section 6.1 |
| VIPL-HR | Official 5-fold CV (Niu et al. 2019) | Section 6.1 |
| iBVP | 80/10/10 subject-level | Section 6.1 |
| SCAMPS | Official split (McDuff et al. 2022) | Section 6.1 |
| OBF | 80/10/10 subject-level | Section 6.1 |

All splits are **subject-level** to prevent frame-level data leakage.
