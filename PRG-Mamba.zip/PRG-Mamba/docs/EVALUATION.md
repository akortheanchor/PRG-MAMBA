# Evaluation Guide

## Single Dataset Evaluation

```bash
python scripts/evaluate.py \
    --config configs/mmpd.yaml \
    --checkpoint results/checkpoints/mmpd_seed42.pth \
    --output results/eval_mmpd.json
```

## Cross-Dataset Transfer (Table 9, Section 6.4)

```bash
# MMPD → UBFC-rPPG
python scripts/cross_dataset.py \
    --train_config configs/mmpd.yaml \
    --test_config  configs/ubfc.yaml \
    --checkpoint   results/checkpoints/mmpd_seed42.pth

# PURE → UBFC-rPPG
python scripts/cross_dataset.py \
    --train_config configs/pure.yaml \
    --test_config  configs/ubfc.yaml \
    --checkpoint   results/checkpoints/pure_seed42.pth
```

## Ablation Studies (Section 6.6)

```bash
# OctaAug cumulative ablation (Table 11)
python scripts/ablation.py --config configs/mmpd.yaml --study octaaug

# Graph Mamba vs Graph Transformer (Table 10)
python scripts/ablation.py --config configs/ubfc.yaml --study graph

# lambda3 sensitivity (Table 12)
python scripts/ablation.py --config configs/pure.yaml --study lambda3

# Windowing sensitivity (Table 13)
python scripts/ablation.py --config configs/mmpd.yaml --study window

# All ablations
python scripts/ablation.py --config configs/mmpd.yaml --study all
```

## Expected Results

### HR Estimation (Table 4, Section 6.3.1)

| Dataset | MAE ↓ | RMSE ↓ | r ↑ |
|---------|--------|--------|-----|
| PURE | 0.58 | 0.78 | 1.0000 |
| UBFC-rPPG | 0.19 | 0.26 | 1.0000 |
| MMPD | 4.38 | 8.02 | 0.7401 |
| VIPL-HR | 6.41 | 8.68 | 0.7120 |
| iBVP | 0.37 | 0.50 | 0.9998 |
| SCAMPS | 2.71 | 3.66 | 0.8730 |
| OBF | 0.24 | 0.32 | 1.0000 |

All improvements p < 0.01 (Wilcoxon signed-rank).

### Blockchain Evaluation (Table 8, Section 6.7)

| Metric | Expected value |
|--------|---------------|
| Blocks per run | 500 |
| Tamper detection rate | 100% (300/300) |
| Audit consistency | 100% |
| Overhead | ~10.5% |

## Reproducing Paper Figures

```bash
# Generate all publication figures
python results/generate_figures.py \
    --eval_dir results/ \
    --output_dir results/figures/
```

Figures produced:
- `fig03_training_curves.png` — convergence curves (Figure 3)
- `fig05_scatter.png` — predicted vs GT HR scatter (Figure 5)
- `fig06_bland_altman.png` — Bland-Altman agreement (Figure 6)
- `fig07_psd.png` — PSD comparison (Figure 7)
- `fig08_waveforms.png` — BVP waveform reconstruction (Figure 8)
- `fig09_ablation.png` — ablation study (Figure 9)
- `fig10_skin_activity.png` — skin-tone stratification (Figure 10)
- `fig11_efficiency.png` — efficiency comparison (Figure 11)
- `fig12_dashboard.png` — grand dashboard (Figure 12)
