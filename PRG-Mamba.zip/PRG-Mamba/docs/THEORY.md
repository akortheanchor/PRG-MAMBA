# Theoretical Reference

Quick-reference for all formal results in PRG-Mamba.

---

## OctaAug Theoretical Guarantees

### Appendix A — TCM Dirichlet Kernel (Eq. A.4)
Temporal CutMix attenuates the dominant BVP spectral peak by:
```
|X_tilde(ω₁)| / |X₁(ω₁)| ≈ (T - L) / T
```
where L is the replaced segment length and T is the clip length.

### Proposition 1 — CDR Spectral Bound (Section 4.4)
Under CDR with white-balance matrix A_wb, the BVP fundamental
at f₀ = HR/60 is attenuated by a factor bounded in [0.75, 1.30].

### Theorem 1 — PBSM SNR Gain (Section 4.5, Eq. 14)
```
SNR(s̃, f₀) ≥ SNR(ŝ, f₀) + 10·log₁₀(‖η_{f_η}‖² / (σ_ξ² · B_mask))
```
whenever the interference power exceeds replacement noise power.

### Proposition 2 — GPP BVP Preservation (Section 4.6, Eq. 3)
```
|s_{f̃}[t] - s_f[t]| < 0.05·σ_s   for |φ| < 20° and |σ-1| < 0.15
```

### Theorem 2 — ASTE Beer-Lambert Bound (Section 4.8, Eq. 33)
```
Ã_BVP = α_G · A_BVP + (1 - α_G) · Ā_skin
```
BVP temporal structure s[t]/A_BVP is preserved exactly.

---

## Graph Construction

### Eq. (6) — Delta range
```
Δ_min = floor(fs × 60 / 200)  =  9 frames @ 30fps
Δ_max = floor(fs × 60 / 40)   = 45 frames @ 30fps
```

### TRR Recalibration — Eq. (28)
```
Δ_TRR = floor(f_s* × 60 / HR_est)
       ∈ [floor(20×60/200), floor(60×60/40)] = [6, 90]
```

### Effective Receptive Field — Eqs. (8)-(10)
```
ERF_intra(L) = {j : |i-j| ≤ L·(P+F)/2}
ERF_inter(L) = {i + k·Δ : k ∈ ℤ, 0 < |k| ≤ L}
```

---

## Graph Mamba

### Selective SSM (Eqs. 11-15)
```
Δ_t  = softplus(g[j_t] · W_Δ + b_Δ)          (input-dependent)
Ā_t  = exp(Δ_t · A)                            (A: HiPPO, negative)
B̄_t  = Δ_t · (g[j_t] · W_B)
h[t] = Ā_t ⊙ h[t-1] + B̄_t                    (state update)
o[j_t] = g[j_t] + σ(g[j_t]·W_G) ⊙ (h[t]·W_C) (gated output)
```

### Complexity (Table 4)
```
Graph Mamba: O(|E| · d_g)         (0.21× dense Transformer)
Graph Transformer: O(|E| · d_k)   (0.31× dense Transformer)
R-GCN + Mamba: O(T·d_g·|R| + |E|·d_g)  (0.29× dense Transformer)
```

### Gradient Separation (Remark 2)
```
∂L_period / ∂W_{R_intra} = 0
∂L_period / ∂W_{R_inter} ≠ 0
```

---

## Blockchain

### Eq. (25)
```
B_k = H(D_k || B_{k-1})   where H = SHA-256
```

### Theorem 1 — Tamper Evidence
```
Pr[undetected] ≤ 2^{-256} + ε_PBFT(b)
```
where b=4 validators, f < ⌊b/3⌋ Byzantine nodes.

### Corollary 1 — Overhead Ratio (Appendix B, Eq. B.4)
```
γ = (ns + b²) / (L₁·n²·d)
  = (720 + 16) / (12 × 180² × 192)
  ≈ 9.9 × 10⁻⁶
```

---

## Composite Loss

### Eq. (23)
```
L_total = L_time + 0.5·L_freq + 1.0·L_HR + 0.2·L_period
```

| Term | Equation | Supervised component |
|------|----------|---------------------|
| L_NPCC | 1 - cov(ŷ,y)/√(var·var) | BVP waveform shape |
| L_freq | ‖|Ŝ(f)| - |S(f)|‖² | Spectral content |
| L_HR | |ω̂_HR - ω_HR| | Instantaneous HR |
| L_period | (1/T)·Σ‖o[t] - o[t+Δ̂]‖² | Cross-cycle consistency |
