# Training Guide

## Prerequisites

Complete dataset setup as described in `docs/DATASETS.md`.

---

## Single Dataset Training

```bash
# PURE (LOSO, 30 epochs, seed 42)
python scripts/train.py --config configs/pure.yaml

# UBFC-rPPG (80/10/10, 30 epochs)
python scripts/train.py --config configs/ubfc.yaml

# MMPD (official split, 10 epochs)
python scripts/train.py --config configs/mmpd.yaml

# VIPL-HR (official split, 20 epochs)
python scripts/train.py --config configs/vipl.yaml

# iBVP (80/10/10, 25 epochs)
python scripts/train.py --config configs/ibvp.yaml

# SCAMPS (official split, 15 epochs)
python scripts/train.py --config configs/scamps.yaml

# OBF (80/10/10, 30 epochs)
python scripts/train.py --config configs/obf.yaml
```

## Multi-Run (5 seeds, for mean±std reporting)

```bash
python scripts/train.py --config configs/mmpd.yaml --runs 5
```

## Key Hyperparameters (Table 6, Section 5.7)

| Parameter | Value | Config key |
|-----------|-------|-----------|
| Optimiser | Adam | training.optimizer |
| Learning rate | 1e-4 | training.lr |
| Weight decay | 0.01 | training.weight_decay |
| Scheduler | OneCycleLR cosine | training.scheduler |
| Batch size | 4 | training.batch_size |
| Clip length | 128 frames | training.clip_len |
| Graph d_g | 128 | model.pool3d.d_g |
| SSM state N | 16 | model.graph_mamba.N_state |
| λ₁ (freq) | 0.5 | loss.lambda1 |
| λ₂ (HR) | 1.0 | loss.lambda2 |
| λ₃ (period) | 0.2 | loss.lambda3 |

## OctaAug During Training

OctaAug is applied automatically when `augment=True` (default for train split).
PBSM is disabled at epoch 1 (Section 4.5, Remark 1).

To disable specific components:

```yaml
# In your config file or override on command line
octaaug:
  aste:
    prob: 0.0   # Disable ASTE
  gpp:
    prob: 0.0   # Disable GPP
```

## Convergence Criterion

Training stops when validation MAE improvement < 0.01 bpm for 5 consecutive epochs:

```yaml
training:
  convergence_delta: 0.01   # bpm
  convergence_patience: 5   # epochs
```

## Checkpoints

Best checkpoints saved to:
```
results/checkpoints/{dataset}_seed{seed}.pth
```

Each checkpoint contains:
- `epoch`: epoch at which best val MAE was achieved
- `state_dict`: model weights
- `val_mae`: validation MAE at save time
- `cfg`: full config used for training

## GPU Requirements

| Dataset | Approx. training time | GPU RAM |
|---------|----------------------|---------|
| PURE | ~8 min | 12 GB |
| UBFC-rPPG | ~15 min | 12 GB |
| MMPD | ~25 min | 16 GB |
| VIPL-HR | ~45 min | 24 GB |
| SCAMPS | ~90 min | 24 GB |

Tested on NVIDIA A100-80GB (Table 6). Use `--batch_size 2` for smaller GPUs.
