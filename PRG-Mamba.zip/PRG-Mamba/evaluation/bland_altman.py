"""
Bland-Altman Agreement Analysis
==================================
Implements the Bland-Altman agreement analysis used in
Section 6.4 (Cross-Dataset Evaluation) and Figure 6.

Reference:
  Bland, J.M. & Altman, D.G. (1986). Statistical methods
  for assessing agreement between two methods of clinical
  measurement. The Lancet, 1(8476), 307-310.

Paper reference: PRG-Mamba, Section 6.4, Figure 6
"""

import numpy as np
from typing import Dict, Tuple


def bland_altman(
    method_a: np.ndarray,
    method_b: np.ndarray,
) -> Dict:
    """
    Compute Bland-Altman statistics for two measurement methods.

    Args:
        method_a: (N,) array — ground-truth HR values
        method_b: (N,) array — predicted HR values

    Returns:
        Dict with keys:
          means:    (N,) element-wise mean (x-axis)
          diffs:    (N,) element-wise difference b−a (y-axis)
          bias:     float mean difference (systematic bias)
          sd:       float standard deviation of differences
          loa_hi:   float upper limit of agreement (bias + 1.96σ)
          loa_lo:   float lower limit of agreement (bias − 1.96σ)
          pct_within_loa: float % points within LoA
    """
    a = np.asarray(method_a, dtype=np.float64)
    b = np.asarray(method_b, dtype=np.float64)
    assert a.shape == b.shape, "Arrays must have equal length"

    means  = (a + b) / 2.0
    diffs  = b - a
    bias   = float(diffs.mean())
    sd     = float(diffs.std(ddof=1))
    loa_hi = bias + 1.96 * sd
    loa_lo = bias - 1.96 * sd

    within = np.sum((diffs >= loa_lo) & (diffs <= loa_hi))
    pct    = float(within / len(diffs) * 100.0)

    return {
        'means'           : means,
        'diffs'           : diffs,
        'bias'            : bias,
        'sd'              : sd,
        'loa_hi'          : loa_hi,
        'loa_lo'          : loa_lo,
        'pct_within_loa'  : pct,
        'n'               : int(len(diffs)),
    }


def print_bland_altman_summary(result: Dict, label: str = ''):
    """Pretty-print Bland-Altman statistics."""
    print(f"Bland-Altman {label}:")
    print(f"  Bias   : {result['bias']:+.3f} bpm")
    print(f"  SD     : {result['sd']:.3f} bpm")
    print(f"  LoA    : [{result['loa_lo']:+.3f}, {result['loa_hi']:+.3f}] bpm")
    print(f"  Within : {result['pct_within_loa']:.1f}% of observations")
