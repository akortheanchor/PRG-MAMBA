"""
HRV Analysis Module
====================
Implements HRV metrics from Section 6.3.2:
  IBI:   Inter-beat interval (ms)
  SDNN:  Standard deviation of NN intervals (ms)
  SD1:   Short-term HRV — vagal tone (ms)
  SD2:   Long-term HRV — sympathovagal balance (ms)

Following HRV Task Force guidelines (Malik et al. 1996).

Paper reference: PRG-Mamba, Section 6.3.2, Table 5
"""

import numpy as np
from scipy.signal import find_peaks
from typing import Dict, List, Optional, Tuple


def extract_ibi_sequence(
    bvp: np.ndarray,
    fs: float = 30.0,
    hr_est: float = 75.0,
    prominence: float = 0.3,
) -> np.ndarray:
    """
    Extract IBI sequence from BVP signal via peak detection.

    Uses scipy.signal.find_peaks with a physiologically grounded
    minimum inter-peak distance of 0.7 × cardiac period.

    Args:
        bvp:       (T,) BVP signal (normalised to zero mean, unit std)
        fs:        Frame rate in fps
        hr_est:    Estimated HR in bpm (for min distance constraint)
        prominence: Peak prominence threshold

    Returns:
        ibi: (K,) inter-beat intervals in milliseconds
    """
    hr_safe  = float(np.clip(hr_est, 40.0, 200.0))
    min_dist = max(3, int(0.7 * fs * 60.0 / hr_safe))

    peaks, props = find_peaks(
        bvp,
        distance=min_dist,
        prominence=prominence,
    )

    if len(peaks) < 2:
        # Fallback: return single IBI from HR estimate
        return np.array([60.0 / hr_safe * 1000.0])

    ibi_frames = np.diff(peaks)           # frames between peaks
    ibi_ms     = ibi_frames / fs * 1000.0 # convert to milliseconds
    return ibi_ms.astype(np.float64)


def sdnn(ibi_ms: np.ndarray) -> float:
    """
    Standard deviation of NN intervals (SDNN) in milliseconds.
    Task Force definition: std with ddof=1.
    """
    if len(ibi_ms) < 2:
        return 0.0
    return float(np.std(ibi_ms, ddof=1))


def rmssd(ibi_ms: np.ndarray) -> float:
    """
    Root mean square of successive differences (RMSSD) in ms.
    """
    if len(ibi_ms) < 2:
        return 0.0
    successive_diff = np.diff(ibi_ms)
    return float(np.sqrt(np.mean(successive_diff ** 2)))


def poincare_sd1_sd2(ibi_ms: np.ndarray) -> Tuple:
    """
    Poincaré plot SD1 and SD2 (Section 6.3.2).

    SD1: standard deviation perpendicular to the identity line
         (short-term HRV, vagal modulation)
    SD2: standard deviation along the identity line
         (long-term HRV, sympathovagal balance)

    Returns:
        (SD1, SD2) in milliseconds
    """
    if len(ibi_ms) < 2:
        return 0.0, 0.0

    x   = ibi_ms[:-1]    # RR_n
    y   = ibi_ms[1:]     # RR_{n+1}

    sd1 = float(np.std((y - x) / np.sqrt(2), ddof=1))
    sd2 = float(np.sqrt(
        2.0 * np.std(ibi_ms, ddof=1) ** 2 - sd1 ** 2
    ))
    return sd1, sd2


# Re-export for convenience
from typing import Dict, List, Tuple

def compute_all_hrv(
    bvp: np.ndarray,
    fs: float = 30.0,
    hr_est: float = 75.0,
) -> Dict[str, float]:
    """
    Compute all HRV metrics from a predicted BVP signal.

    Args:
        bvp:    (T,) predicted BVP signal
        fs:     Frame rate
        hr_est: Estimated HR in bpm

    Returns:
        Dict with IBI_mean, IBI_std, SDNN, RMSSD, SD1, SD2,
        SD1_SD2_ratio — all in milliseconds where applicable
    """
    ibi = extract_ibi_sequence(bvp, fs, hr_est)
    sd1, sd2 = poincare_sd1_sd2(ibi)

    return {
        'IBI_mean'      : float(np.mean(ibi)),
        'IBI_std'       : float(np.std(ibi, ddof=1)) if len(ibi)>1 else 0.0,
        'SDNN_ms'       : sdnn(ibi),
        'RMSSD_ms'      : rmssd(ibi),
        'SD1_ms'        : sd1,
        'SD2_ms'        : sd2,
        'SD1_SD2_ratio' : float(sd1 / (sd2 + 1e-8)),
        'n_beats'       : int(len(ibi) + 1),
    }
