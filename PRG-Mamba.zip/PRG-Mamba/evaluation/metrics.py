"""
Evaluation Metrics
==================
Implements Eqs. (24)-(26) from Section 6.3:
  MAE  = (1/N) * sum |y_i - y_hat_i|
  RMSE = sqrt((1/N) * sum (y_i - y_hat_i)^2)
  MAPE = (100/N) * sum |y_i - y_hat_i| / |y_i|

Also implements HRV metrics (Section 6.3.2):
  IBI, SDNN, SD1/SD2 (Poincaré ratio)

Paper reference: PRG-Mamba, Section 6.3
"""

import numpy as np
from scipy.signal import find_peaks
from scipy.stats import pearsonr
from typing import Dict, List, Tuple, Union


# ── HR Estimation Metrics ─────────────────────────────────────────────────

def compute_hr_from_bvp(
    bvp: np.ndarray,
    fs: float = 30.0,
    f_lo: float = 0.5,
    f_hi: float = 4.0,
    n_fft: int = 2048
) -> float:
    """
    Estimate HR from BVP signal via spectral peak detection.

    Args:
        bvp:   (T,) BVP signal
        fs:    Frame rate
        f_lo:  Lower BVP band (Hz)
        f_hi:  Upper BVP band (Hz)
        n_fft: FFT length

    Returns:
        hr: Estimated HR in bpm
    """
    freqs  = np.fft.rfftfreq(n_fft, d=1.0 / fs)
    psd    = np.abs(np.fft.rfft(bvp, n=n_fft)) ** 2
    mask   = (freqs >= f_lo) & (freqs <= f_hi)
    if not mask.any():
        return 75.0
    peak_f = freqs[mask][np.argmax(psd[mask])]
    return float(peak_f * 60.0)


def compute_mae(
    gt: np.ndarray,
    pred: np.ndarray
) -> float:
    """Mean Absolute Error (Eq. 24)."""
    return float(np.abs(gt - pred).mean())


def compute_rmse(
    gt: np.ndarray,
    pred: np.ndarray
) -> float:
    """Root Mean Square Error (Eq. 25)."""
    return float(np.sqrt(((gt - pred) ** 2).mean()))


def compute_mape(
    gt: np.ndarray,
    pred: np.ndarray,
    eps: float = 1e-8
) -> float:
    """Mean Absolute Percentage Error (Eq. 26)."""
    return float(100.0 * (np.abs(gt - pred) / (np.abs(gt) + eps)).mean())


def compute_pearson_r(
    gt: np.ndarray,
    pred: np.ndarray
) -> Tuple[float, float]:
    """Pearson correlation coefficient and p-value."""
    if len(gt) < 3:
        return 0.0, 1.0
    r, p = pearsonr(gt.flatten(), pred.flatten())
    return float(r), float(p)


def compute_hr_metrics(
    gt_hrs: np.ndarray,
    pred_hrs: np.ndarray
) -> Dict[str, float]:
    """
    Compute all HR estimation metrics for a batch of subjects.

    Args:
        gt_hrs:   (N,) ground-truth HR values (bpm)
        pred_hrs: (N,) predicted HR values (bpm)

    Returns:
        Dict with keys: mae, rmse, mape, r, p
    """
    gt   = np.array(gt_hrs, dtype=np.float64)
    pred = np.array(pred_hrs, dtype=np.float64)
    r, p = compute_pearson_r(gt, pred)

    return {
        'mae' : compute_mae(gt, pred),
        'rmse': compute_rmse(gt, pred),
        'mape': compute_mape(gt, pred),
        'r'   : r,
        'p'   : p,
    }


# ── HRV Metrics ───────────────────────────────────────────────────────────

def extract_ibi(
    bvp: np.ndarray,
    fs: float = 30.0,
    hr_est: float = 75.0
) -> np.ndarray:
    """
    Extract inter-beat intervals (IBI) from BVP signal.

    Uses scipy.signal.find_peaks with physiologically
    grounded minimum inter-peak distance (Section 6.3.2).

    Args:
        bvp:    (T,) BVP signal (normalised)
        fs:     Frame rate
        hr_est: Estimated HR for minimum distance constraint

    Returns:
        ibi: (K,) inter-beat intervals in seconds
    """
    min_dist = max(3, int(0.7 * fs * 60.0 / max(hr_est, 40.0)))
    peaks, _ = find_peaks(bvp, distance=min_dist)

    if len(peaks) < 2:
        return np.array([60.0 / max(hr_est, 40.0)])

    ibi_frames = np.diff(peaks)
    return ibi_frames / fs   # convert to seconds


def compute_sdnn(ibi: np.ndarray) -> float:
    """
    Standard deviation of NN intervals.
    HRV Task Force guideline: SDNN in milliseconds.

    Args:
        ibi: (K,) IBI values in seconds

    Returns:
        sdnn: SDNN in milliseconds
    """
    return float(np.std(ibi, ddof=1) * 1000.0)


def compute_sd1_sd2(ibi: np.ndarray) -> Tuple[float, float]:
    """
    Poincaré plot SD1 and SD2 (Section 6.3.2).

    SD1: short-term HRV (vagal tone)
    SD2: long-term HRV (sympathovagal balance)

    Args:
        ibi: (K,) IBI values in seconds

    Returns:
        (sd1, sd2) in milliseconds
    """
    if len(ibi) < 2:
        return 0.0, 0.0

    diff = np.diff(ibi) * 1000.0   # ms
    sd1  = float(np.std(diff, ddof=1) / np.sqrt(2))
    sd2  = float(np.sqrt(2 * np.std(ibi * 1000.0, ddof=1) ** 2 - sd1 ** 2))
    return sd1, sd2


def compute_hrv_metrics(
    bvp: np.ndarray,
    fs: float = 30.0,
    hr_est: float = 75.0
) -> Dict[str, float]:
    """
    Compute IBI, SDNN, SD1/SD2 from predicted BVP signal.

    Args:
        bvp:    (T,) predicted BVP
        fs:     Frame rate
        hr_est: HR estimate for IBI extraction

    Returns:
        Dict with keys: ibi_mean, ibi_std, sdnn, sd1, sd2, sd1_sd2_ratio
    """
    ibi  = extract_ibi(bvp, fs, hr_est)
    sd1, sd2 = compute_sd1_sd2(ibi)

    return {
        'ibi_mean'      : float(np.mean(ibi) * 1000.0),    # ms
        'ibi_std'       : float(np.std(ibi,  ddof=1) * 1000.0),
        'sdnn'          : compute_sdnn(ibi),
        'sd1'           : sd1,
        'sd2'           : sd2,
        'sd1_sd2_ratio' : float(sd1 / (sd2 + 1e-8)),
    }


# ── Per-Subject Evaluation ────────────────────────────────────────────────

def evaluate_subject(
    pred_bvp: np.ndarray,
    gt_bvp:   np.ndarray,
    gt_hr:    float,
    fs:       float = 30.0,
) -> Dict[str, float]:
    """
    Full per-subject evaluation.

    Args:
        pred_bvp: (T,) predicted BVP
        gt_bvp:   (T,) ground-truth BVP
        gt_hr:    Ground-truth HR in bpm
        fs:       Frame rate

    Returns:
        Dict with all HR and HRV metrics
    """
    pred_hr = compute_hr_from_bvp(pred_bvp, fs)

    hr_metrics  = compute_hr_metrics(
        np.array([gt_hr]), np.array([pred_hr])
    )
    hrv_metrics = compute_hrv_metrics(pred_bvp, fs, pred_hr)

    return {**hr_metrics, **hrv_metrics, 'pred_hr': pred_hr}
