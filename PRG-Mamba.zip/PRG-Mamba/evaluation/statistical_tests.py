"""
Statistical Tests for Evaluation
==================================
Implements the two-tailed Wilcoxon signed-rank test
used throughout Section 6.3.3 and all ablation tables.

Rationale for non-parametric test (Section 7.5.3):
Per-subject MAE distributions are right-skewed on MMPD
and VIPL-HR where a small number of Fitzpatrick V-VI or
extreme-pose subjects dominate the upper tail.
The Wilcoxon test makes no distributional assumptions.

Paper reference: PRG-Mamba, Sections 6.3.3, 7.5.3
"""

import numpy as np
from scipy.stats import wilcoxon
from typing import Dict, List, Tuple


def wilcoxon_test(
    errors_a: List[float],
    errors_b: List[float],
    alpha: float = 0.05,
    alternative: str = 'two-sided'
) -> Dict:
    """
    Two-tailed Wilcoxon signed-rank test.

    Tests H0: median(errors_a) == median(errors_b)
    vs    H1: median(errors_a) != median(errors_b)

    Unit of observation: per-subject MAE (Section 6.3.3).

    Args:
        errors_a: Per-subject errors for method A (e.g., PRG-Mamba)
        errors_b: Per-subject errors for method B (e.g., baseline)
        alpha:    Significance level (default 0.05)
        alternative: 'two-sided', 'less', or 'greater'

    Returns:
        Dict with keys: statistic, p_value, significant,
                        effect_size (rank-biserial r)
    """
    a = np.array(errors_a, dtype=np.float64)
    b = np.array(errors_b, dtype=np.float64)

    if len(a) != len(b):
        raise ValueError(
            f"Paired test requires equal lengths: {len(a)} vs {len(b)}"
        )

    stat, p = wilcoxon(a, b, alternative=alternative, zero_method='wilcox')

    # Effect size: rank-biserial correlation r = 1 - 2W/n(n+1)/2
    n = len(a)
    r = 1.0 - (2.0 * stat) / (n * (n + 1) / 2.0)

    return {
        'statistic'  : float(stat),
        'p_value'    : float(p),
        'significant': bool(p < alpha),
        'effect_size': float(r),
        'n_subjects' : int(n),
        'alpha'      : alpha,
    }


def pairwise_significance_table(
    method_errors: Dict[str, List[float]],
    reference_method: str,
    alpha: float = 0.05
) -> Dict[str, Dict]:
    """
    Compute pairwise significance between reference method
    and all other methods.

    Args:
        method_errors:    {method_name: [per-subject MAE]}
        reference_method: Name of reference method (e.g., 'PRG-Mamba')
        alpha:            Significance level

    Returns:
        Dict {method_name: wilcoxon_test result}
    """
    ref_errors = method_errors[reference_method]
    results    = {}

    for name, errors in method_errors.items():
        if name == reference_method:
            continue
        try:
            results[name] = wilcoxon_test(ref_errors, errors, alpha)
        except Exception as e:
            results[name] = {'error': str(e)}

    return results


def summarise_significance(results: Dict[str, Dict]) -> str:
    """Format significance table for console output."""
    lines = [
        f"{'Method':<25} {'p-value':>10} {'Sig?':>6} {'Effect r':>10}"
    ]
    lines.append('-' * 55)
    for name, r in results.items():
        if 'error' in r:
            lines.append(f"{name:<25}  ERROR: {r['error']}")
        else:
            sig  = '✓' if r['significant'] else '✗'
            lines.append(
                f"{name:<25} {r['p_value']:>10.4f} {sig:>6}"
                f" {r['effect_size']:>10.3f}"
            )
    return '\n'.join(lines)
