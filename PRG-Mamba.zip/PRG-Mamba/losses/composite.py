"""
Composite Training Loss
========================
Implements Eq. (23) from Section 5.5.4:

  L_total = L_time + lambda1 * L_freq + lambda2 * L_HR + lambda3 * L_period

Each loss term is aligned to a specific architectural component:
  L_NPCC   → BVP waveform output of decoder
  L_freq   → spectral content (interacts with PBSM)
  L_HR     → instantaneous HR estimate
  L_period → Graph Mamba embeddings (gradient via W_{R_inter} only, Remark 2)

Paper reference: PRG-Mamba, Section 5.5.4
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional


class NPCCLoss(nn.Module):
    """
    Normalised Pearson Cross-Correlation loss.

    Implements Eq. (22): L_NPCC = 1 - cov(y_hat, y) / sqrt(var*var)

    Amplitude-invariant: remains well-defined even when ASTE
    reduces BVP amplitude (Theorem 2, Section 4.8).

    Args:
        eps: Numerical stability constant
    """

    def __init__(self, eps: float = 1e-8):
        super().__init__()
        self.eps = eps

    def forward(
        self,
        pred: torch.Tensor,
        gt: torch.Tensor
    ) -> torch.Tensor:
        """
        Args:
            pred: (T,) or (B, T) predicted BVP
            gt:   (T,) or (B, T) ground-truth BVP

        Returns:
            loss: scalar NPCC loss in [0, 2]
        """
        if pred.dim() == 1:
            pred = pred.unsqueeze(0)
            gt   = gt.unsqueeze(0)

        pred_m = pred - pred.mean(dim=-1, keepdim=True)
        gt_m   = gt   - gt.mean(dim=-1, keepdim=True)

        num  = (pred_m * gt_m).sum(dim=-1)
        denom = (
            torch.sqrt((pred_m ** 2).sum(dim=-1) + self.eps)
            * torch.sqrt((gt_m   ** 2).sum(dim=-1) + self.eps)
        )
        r = num / denom
        return (1.0 - r).mean()


class FrequencyLoss(nn.Module):
    """
    Frequency-domain spectral magnitude loss.

    Implements Eq. (19):
      L_freq = || |S_hat(f)| - |S_gt(f)| ||^2

    Interacts with PBSM (Section 4.5): when PBSM masks a
    sub-band, the elevated L_freq gradient forces the model
    to reconstruct masked frequencies from context
    (Theorem 1, SNR gain guarantee).

    Args:
        n_fft: FFT length for spectral resolution
        fs:    Frame rate for frequency axis
        f_lo:  Lower BVP band limit (Hz)
        f_hi:  Upper BVP band limit (Hz)
    """

    def __init__(
        self,
        n_fft: int = 512,
        fs: float = 30.0,
        f_lo: float = 0.5,
        f_hi: float = 4.0
    ):
        super().__init__()
        self.n_fft = n_fft
        self.fs    = fs
        freqs      = torch.fft.rfftfreq(n_fft, d=1.0 / fs)
        self.register_buffer(
            'band_mask',
            (freqs >= f_lo) & (freqs <= f_hi)
        )

    def forward(
        self,
        pred: torch.Tensor,
        gt: torch.Tensor
    ) -> torch.Tensor:
        """
        Args:
            pred: (T,) or (B, T) predicted BVP
            gt:   (T,) or (B, T) ground-truth BVP

        Returns:
            loss: scalar frequency loss
        """
        if pred.dim() == 1:
            pred = pred.unsqueeze(0)
            gt   = gt.unsqueeze(0)

        P = torch.abs(torch.fft.rfft(pred, n=self.n_fft, dim=-1))
        G = torch.abs(torch.fft.rfft(gt,   n=self.n_fft, dim=-1))

        # Normalise within BVP band
        P_band = P[..., self.band_mask]
        G_band = G[..., self.band_mask]
        P_norm = P_band / (P_band.amax(dim=-1, keepdim=True) + 1e-8)
        G_norm = G_band / (G_band.amax(dim=-1, keepdim=True) + 1e-8)

        return F.mse_loss(P_norm, G_norm)


class HRLoss(nn.Module):
    """
    Instantaneous HR prediction loss.

    Implements Eq. (20): L_HR = |omega_hat_HR - omega_gt_HR|

    Args:
        fs:    Frame rate
        n_fft: FFT length
        f_lo:  Lower BVP band limit (Hz)
        f_hi:  Upper BVP band limit (Hz)
    """

    def __init__(
        self,
        fs: float = 30.0,
        n_fft: int = 512,
        f_lo: float = 0.5,
        f_hi: float = 4.0
    ):
        super().__init__()
        self.fs    = fs
        self.n_fft = n_fft
        freqs      = torch.fft.rfftfreq(n_fft, d=1.0 / fs)
        self.register_buffer('freqs', freqs)
        self.register_buffer(
            'band_mask',
            (freqs >= f_lo) & (freqs <= f_hi)
        )

    def _peak_hr(self, x: torch.Tensor) -> torch.Tensor:
        """Extract HR from spectral peak in BVP band (bpm)."""
        psd  = torch.abs(torch.fft.rfft(x, n=self.n_fft, dim=-1)) ** 2
        band = psd[..., self.band_mask]
        freqs_band = self.freqs[self.band_mask]
        peak_idx   = band.argmax(dim=-1)
        peak_freq  = freqs_band[peak_idx]           # Hz
        return peak_freq * 60.0                      # bpm

    def forward(
        self,
        pred: torch.Tensor,
        gt: torch.Tensor
    ) -> torch.Tensor:
        """
        Args:
            pred: (T,) or (B, T) predicted BVP
            gt:   (T,) or (B, T) ground-truth BVP

        Returns:
            loss: mean absolute HR error (normalised by 60)
        """
        if pred.dim() == 1:
            pred = pred.unsqueeze(0)
            gt   = gt.unsqueeze(0)

        hr_pred = self._peak_hr(pred)
        hr_gt   = self._peak_hr(gt)
        return torch.abs(hr_pred - hr_gt).mean() / 60.0


class PeriodicityLoss(nn.Module):
    """
    Cross-cycle embedding consistency loss.

    Implements Eq. (21):
      L_period = (1/T) * sum_t || o[t] - o[t + delta_hat] ||^2

    Gradient routing (Remark 2, Section 5.4.4):
    Because L_period depends only on o[t] = Graph Mamba output
    which flows through W_{R_inter}, its gradient updates ONLY
    W_{R_inter}, leaving W_{R_intra} unaffected.

    Args:
        fs:    Frame rate for delta computation
    """

    def __init__(self, fs: float = 30.0):
        super().__init__()
        self.fs = fs

    def forward(
        self,
        embeddings: torch.Tensor,
        hr_est: float
    ) -> torch.Tensor:
        """
        Args:
            embeddings: (T, d_g) Graph Mamba output embeddings o[t]
            hr_est:     Estimated HR in bpm

        Returns:
            loss: scalar periodicity consistency loss
        """
        T, d = embeddings.shape
        hr_safe = max(float(hr_est), 40.0)
        delta   = int(round(self.fs * 60.0 / hr_safe))
        delta   = max(1, min(delta, T - 1))

        pairs_a = embeddings[:T - delta]    # o[t]
        pairs_b = embeddings[delta:]        # o[t + delta]

        return F.mse_loss(pairs_a, pairs_b)


class CompositeLoss(nn.Module):
    """
    Composite training loss (Eq. 23):

      L_total = L_time + lambda1*L_freq + lambda2*L_HR + lambda3*L_period

    Hyperparameters (grid-searched on PURE validation, Table 5):
      lambda1 = 0.5   (frequency loss)
      lambda2 = 1.0   (HR loss)
      lambda3 = 0.2   (periodicity loss; small to avoid over-constraining
                       in early epochs when HR estimate is unreliable)

    Args:
        lambda1: Frequency loss weight
        lambda2: HR loss weight
        lambda3: Periodicity loss weight
        fs:      Frame rate
    """

    def __init__(
        self,
        lambda1: float = 0.5,
        lambda2: float = 1.0,
        lambda3: float = 0.2,
        fs: float = 30.0,
    ):
        super().__init__()
        self.lambda1 = lambda1
        self.lambda2 = lambda2
        self.lambda3 = lambda3

        self.npcc   = NPCCLoss()
        self.freq   = FrequencyLoss(fs=fs)
        self.hr     = HRLoss(fs=fs)
        self.period = PeriodicityLoss(fs=fs)

    def forward(
        self,
        pred_bvp:   torch.Tensor,   # (T,) or (B,T)
        gt_bvp:     torch.Tensor,   # (T,) or (B,T)
        embeddings: torch.Tensor,   # (T, d_g) Graph Mamba output
        hr_est:     float,
    ) -> dict:
        """
        Compute all loss components and weighted total.

        Returns dict with keys:
          total, npcc, freq, hr, period
        """
        L_npcc   = self.npcc(pred_bvp, gt_bvp)
        L_freq   = self.freq(pred_bvp, gt_bvp)
        L_hr     = self.hr(pred_bvp, gt_bvp)
        L_period = self.period(embeddings, hr_est)

        L_total = (
            L_npcc
            + self.lambda1 * L_freq
            + self.lambda2 * L_hr
            + self.lambda3 * L_period
        )

        return {
            'total' : L_total,
            'npcc'  : L_npcc.item(),
            'freq'  : L_freq.item(),
            'hr'    : L_hr.item(),
            'period': L_period.item(),
        }
