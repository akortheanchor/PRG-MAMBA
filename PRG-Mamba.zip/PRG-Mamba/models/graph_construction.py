"""
Temporal-Periodic Graph Construction
=====================================
Implements the dual-relation graph G=(V,E,R) from Section 5.3:
  - R_intra: local BVP morphology edges (Eq. 4)
  - R_inter: cardiac cycle-to-cycle consistency edges (Eq. 5)

Paper reference: PRG-Mamba, Section 5.3
"""

import torch
import numpy as np
from typing import Tuple, List, Optional


def compute_delta_range(
    fs: float,
    hr_min: float = 40.0,
    hr_max: float = 200.0
) -> Tuple[int, int]:
    """
    Compute inter-period lag range from physiological HR bounds.

    Implements Eq. (6):
        delta_min = floor(fs * 60 / hr_max)
        delta_max = floor(fs * 60 / hr_min)

    Args:
        fs:     Frame rate in fps (25, 30, or 60)
        hr_min: Minimum physiological HR in bpm (default 40)
        hr_max: Maximum physiological HR in bpm (default 200)

    Returns:
        (delta_min, delta_max) in frames
    """
    delta_min = int(np.floor(fs * 60.0 / hr_max))
    delta_max = int(np.floor(fs * 60.0 / hr_min))
    return delta_min, delta_max


def build_intra_edges(T: int, P: int, F: int) -> List[Tuple[int, int]]:
    """
    Build intra-period edge list R_intra.

    Implements Eq. (4): for node i, connect j in [i-P, i+F].
    Direction: j -> i (aggregation at destination i).

    Args:
        T: Number of frames (nodes)
        P: Past window size
        F: Future window size

    Returns:
        List of (src, dst) edge tuples
    """
    edges = []
    for i in range(T):
        for j in range(max(0, i - P), min(T, i + F + 1)):
            if j != i:
                edges.append((j, i))
    return edges


def build_inter_edges(
    T: int,
    delta_min: int,
    delta_max: int,
    hr_est: Optional[float] = None,
    fs: float = 30.0,
    train: bool = True
) -> List[Tuple[int, int]]:
    """
    Build inter-period edge list R_inter.

    Implements Eq. (5): bidirectional edges at lags
    delta in [delta_min, delta_max].

    During training: narrow window [15,25] for efficiency.
    During inference: full physiological range [9,45].
    When hr_est provided: recalibrate delta to match HR.

    Args:
        T:         Number of frames
        delta_min: Minimum lag in frames
        delta_max: Maximum lag in frames
        hr_est:    Estimated HR in bpm (optional)
        fs:        Frame rate in fps
        train:     If True, use narrow training window

    Returns:
        List of (src, dst) edge tuples (bidirectional)
    """
    edges = []

    if hr_est is not None and hr_est > 0:
        # Recalibrate delta to estimated cardiac period (Remark 1)
        delta_est = int(round(fs * 60.0 / hr_est))
        delta_est = np.clip(delta_est, delta_min, delta_max)

        if train:
            # Narrow window ±3 around estimated delta
            d_lo = max(delta_min, delta_est - 3)
            d_hi = min(delta_max, delta_est + 3)
        else:
            d_lo, d_hi = delta_min, delta_max
    else:
        if train:
            d_lo, d_hi = 15, 25   # Training-time default
        else:
            d_lo, d_hi = delta_min, delta_max

    for i in range(T):
        for delta in range(d_lo, d_hi + 1):
            for sign in [1, -1]:
                j = i + sign * delta
                if 0 <= j < T:
                    edges.append((j, i))

    return edges


def build_periodic_graph(
    T: int,
    fs: float = 30.0,
    P: int = 1,
    F: int = 1,
    hr_est: Optional[float] = None,
    train: bool = True,
    hr_min: float = 40.0,
    hr_max: float = 200.0,
    device: str = "cpu"
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    Build the complete Temporal-Periodic Graph G=(V,E,R).

    Returns edge indices and relation masks for both relation types.

    Args:
        T:      Clip length in frames
        fs:     Frame rate in fps
        P:      Intra-period past window
        F:      Intra-period future window
        hr_est: Estimated HR in bpm (None = use full range)
        train:  Training mode flag
        hr_min: Min physiological HR (bpm)
        hr_max: Max physiological HR (bpm)
        device: Torch device string

    Returns:
        intra_edge_index: (2, E_intra) tensor
        inter_edge_index: (2, E_inter) tensor
        intra_edges_list: raw list for R-GCN
        inter_edges_list: raw list for Graph Mamba ordering
    """
    delta_min, delta_max = compute_delta_range(fs, hr_min, hr_max)

    intra_edges = build_intra_edges(T, P, F)
    inter_edges = build_inter_edges(T, delta_min, delta_max,
                                     hr_est, fs, train)

    def to_tensor(edge_list):
        if len(edge_list) == 0:
            return torch.zeros((2, 0), dtype=torch.long, device=device)
        arr = torch.tensor(edge_list, dtype=torch.long, device=device)
        return arr.t().contiguous()

    return (
        to_tensor(intra_edges),
        to_tensor(inter_edges),
        intra_edges,
        inter_edges
    )


class PeriodicGraphBuilder:
    """
    Reusable graph builder that caches edge structures
    when T and delta range are fixed across batches.
    """

    def __init__(
        self,
        T: int = 128,
        fs: float = 30.0,
        P: int = 1,
        F: int = 1,
        hr_min: float = 40.0,
        hr_max: float = 200.0
    ):
        self.T = T
        self.fs = fs
        self.P = P
        self.F = F
        self.hr_min = hr_min
        self.hr_max = hr_max
        self._cache = {}

    def build(
        self,
        hr_est: Optional[float] = None,
        train: bool = True,
        device: str = "cpu"
    ) -> Tuple[torch.Tensor, torch.Tensor, list, list]:
        """Build or retrieve cached graph for given hr_est."""
        # Round hr_est to nearest 2 bpm for cache key
        cache_key = (
            round(hr_est / 2) * 2 if hr_est else None,
            train,
            device
        )
        if cache_key not in self._cache:
            self._cache[cache_key] = build_periodic_graph(
                self.T, self.fs, self.P, self.F,
                hr_est, train, self.hr_min, self.hr_max, device
            )
        return self._cache[cache_key]

    def erf_analysis(self, L: int = 2) -> dict:
        """
        Compute effective receptive field (ERF) analysis.
        Implements Eqs. (8)-(10) from Section 5.3.4.

        Args:
            L: Number of R-GCN layers

        Returns:
            Dictionary with ERF statistics
        """
        erf_intra = L * (self.P + self.F) // 2
        delta_min, delta_max = compute_delta_range(
            self.fs, self.hr_min, self.hr_max)
        erf_inter = {f"±{k}Δ" for k in range(1, L + 1)}

        return {
            "erf_intra_frames": erf_intra,
            "erf_inter_lags": list(erf_inter),
            "delta_min": delta_min,
            "delta_max": delta_max,
            "total_erf_frames": erf_intra + L * delta_max,
        }
