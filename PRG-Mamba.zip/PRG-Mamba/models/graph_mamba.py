"""
Graph Mamba Block
==================
Integrates R-GCN message passing with Selective SSM
refinement over the ordered inter-period neighbourhood.

Architecture (Section 5.4):
  Stage 4a: R-GCN dual-relation aggregation (Eq. 17)
  Stage 4b: Graph Mamba selective SSM (Eqs. 11-15)
  Stage 5:  Cross-attention fusion gate (Eqs. 18-21)

Paper reference: PRG-Mamba, Sections 5.4-5.5
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Tuple, Optional

from models.rgcn import RGCN
from models.selective_ssm import SelectiveSSM


class LayerNorm1d(nn.Module):
    """Layer normalisation over last dimension (T, d_g)."""
    def __init__(self, d: int, eps: float = 1e-6):
        super().__init__()
        self.gamma = nn.Parameter(torch.ones(d))
        self.beta  = nn.Parameter(torch.zeros(d))
        self.eps   = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        mu  = x.mean(-1, keepdim=True)
        sig = x.std(-1, keepdim=True)
        return self.gamma * (x - mu) / (sig + self.eps) + self.beta


class GraphMambaBlock(nn.Module):
    """
    One Graph Mamba block:
      LN → R-GCN → LN → Selective SSM (over inter-period sequence)

    The R-GCN provides structural relation separation.
    The Selective SSM provides content-adaptive lag selectivity.
    Both pathways are fused via the cross-attention gate.

    Args:
        d_g:        Graph embedding dimension (128)
        N_state:    SSM state dimension (16)
        num_rgcn:   Number of R-GCN layers (2)
        dropout:    Dropout rate (0.10)
    """

    def __init__(
        self,
        d_g: int = 128,
        N_state: int = 16,
        num_rgcn: int = 2,
        dropout: float = 0.10,
    ):
        super().__init__()
        self.d_g = d_g

        # R-GCN branch
        self.ln_rgcn = LayerNorm1d(d_g)
        self.rgcn     = RGCN(d_g, num_layers=num_rgcn, dropout=dropout)

        # Graph Mamba SSM branch
        self.ln_mamba = LayerNorm1d(d_g)
        self.ssm      = SelectiveSSM(d_model=d_g, N_state=N_state)

        # Cross-attention fusion gate (Eqs. 18-21)
        self.W_gate  = nn.Linear(d_g * 2, d_g)
        self.dropout = nn.Dropout(dropout)
        self.ln_out  = LayerNorm1d(d_g)

    def _order_inter_nodes(
        self,
        inter_edges: List[Tuple[int, int]],
        T: int
    ) -> List[int]:
        """
        Collect and sort inter-period neighbour indices
        by temporal position for the SSM scan.

        Implements Eq. (10):
            S(i) = sort_t({j : (i,j) in R_inter})

        Returns sorted unique node indices.
        """
        nodes = sorted(set(
            [j for (_, j) in inter_edges] +
            [i for (i, _) in inter_edges]
        ))
        return nodes

    def forward(
        self,
        H: torch.Tensor,
        intra_edges: List[Tuple[int, int]],
        inter_edges: List[Tuple[int, int]],
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass through R-GCN + Graph Mamba + fusion gate.

        Args:
            H:           (T, d_g) input node embeddings (Pool3D output)
            intra_edges: R_intra edge list
            inter_edges: R_inter edge list

        Returns:
            fused:    (T, d_g) fused output Z_fused (Eq. 20)
            g:        (T, d_g) R-GCN output (for loss routing, Remark 2)
        """
        T = H.shape[0]

        # ── R-GCN branch ──────────────────────────────────────────────
        # LN → R-GCN → residual
        g = self.rgcn(self.ln_rgcn(H), intra_edges, inter_edges)
        Z_rgcn = H + g                          # residual (T, d_g)

        # ── Graph Mamba branch ────────────────────────────────────────
        # Order inter-period nodes temporally for SSM scan (Eq. 10)
        inter_nodes = self._order_inter_nodes(inter_edges, T)

        Z_mamba = Z_rgcn.clone()
        if len(inter_nodes) > 0:
            seq_in  = self.ln_mamba(Z_rgcn)[inter_nodes]  # (K, d_g)
            seq_out = self.ssm(seq_in)                     # (K, d_g)
            for k, node in enumerate(inter_nodes):
                Z_mamba[node] = Z_rgcn[node] + seq_out[k] # residual

        # ── Cross-attention fusion gate (Eqs. 18-21) ─────────────────
        # Z_cat = [Z_RGCN || Z_Mamba]  →  gate  →  weighted sum
        Z_cat   = torch.cat([Z_rgcn, Z_mamba], dim=-1)    # (T, 2*d_g)
        alpha   = torch.sigmoid(self.W_gate(Z_cat))        # (T, d_g)
        fused   = alpha * Z_rgcn + (1.0 - alpha) * Z_mamba # (T, d_g)
        fused   = self.dropout(self.ln_out(fused))

        return fused, g


class GraphMambaEncoder(nn.Module):
    """
    Full Graph Mamba encoder with Conv1D decoder.

    Wraps GraphMambaBlock and adds the temporal
    convolutional decoder (Eq. 22).

    Args:
        d_g:        Graph embedding dimension (128)
        N_state:    SSM state dimension (16)
        kernel_size: Conv1D decoder kernel (7 frames)
        dropout:    Dropout rate
    """

    def __init__(
        self,
        d_g: int = 128,
        N_state: int = 16,
        kernel_size: int = 7,
        dropout: float = 0.10,
    ):
        super().__init__()
        self.block = GraphMambaBlock(d_g, N_state, dropout=dropout)

        # Conv1D decoder: (T, d_g) → (T, 1) → squeeze → (T,)
        # k_c = 7 frames ≈ 233ms at 30fps (Section 5.5.2)
        self.decoder = nn.Sequential(
            nn.Linear(d_g, d_g),
            nn.GELU(),
            nn.Conv1d(d_g, d_g, kernel_size=kernel_size,
                      padding=kernel_size // 2, groups=1),
            nn.Conv1d(d_g, 1, kernel_size=1),
        )

    def forward(
        self,
        H: torch.Tensor,
        intra_edges: List[Tuple[int, int]],
        inter_edges: List[Tuple[int, int]],
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Args:
            H:           (T, d_g) Pool3D node features
            intra_edges: R_intra edges
            inter_edges: R_inter edges

        Returns:
            bvp_pred: (T,) predicted BVP signal
            fused:    (T, d_g) fused embeddings (for periodicity loss)
            g:        (T, d_g) R-GCN embeddings (for gradient routing)
        """
        fused, g = self.block(H, intra_edges, inter_edges)

        # Decode: (T, d_g) → (T,)
        z = self.decoder[0](fused)          # Linear
        z = self.decoder[1](z)              # GELU
        z = z.T.unsqueeze(0)               # (1, d_g, T)
        z = self.decoder[2](z)             # Conv1d(d_g, d_g, k)
        z = self.decoder[3](z)             # Conv1d(d_g, 1, 1)
        bvp_pred = z.squeeze(0).squeeze(0) # (T,)

        # Normalise predicted BVP
        bvp_pred = (bvp_pred - bvp_pred.mean()) / (bvp_pred.std() + 1e-8)

        return bvp_pred, fused, g
