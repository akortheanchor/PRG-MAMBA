"""
Relational Graph Convolutional Network (R-GCN)
================================================
Implements the dual-relation R-GCN from Section 5.4
(Eq. 17). Assigns independent weight matrices to
R_intra and R_inter, ensuring gradient separation
(Remark 2, Section 5.4.4).

Paper reference: PRG-Mamba, Section 5.4
Based on: Schlichtkrull et al. (2017), Modeling
          Relational Data with Graph Convolutional Networks.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Tuple


class RGCNLayer(nn.Module):
    """
    Single R-GCN layer with intra- and inter-period relations.

    Implements Eq. (17):
        g[i] = sigma( sum_{r in R} sum_{j in N_r(i)}
                      (1/|N_r(i)|) * W_r * h[j]  +  W_0 * h[i] )

    Relation-specific weight matrices W_r are initialised
    with Kaiming uniform (Section 5.4.3), ensuring gradient
    separation (Remark 2): L_period updates ONLY W_{R_inter}.

    Args:
        d_g:          Graph embedding dimension
        use_bn:       Apply batch normalisation between layers
        dropout:      Dropout rate
        activation:   Activation function (default ReLU)
    """

    def __init__(
        self,
        d_g: int = 128,
        use_bn: bool = True,
        dropout: float = 0.1,
        activation: str = "relu",
    ):
        super().__init__()
        self.d_g = d_g

        # Relation-specific weight matrices (Eq. 17)
        self.W_intra = nn.Linear(d_g, d_g, bias=False)
        self.W_inter = nn.Linear(d_g, d_g, bias=False)
        self.W_self  = nn.Linear(d_g, d_g, bias=True)   # self-loop W_0

        # Kaiming uniform initialisation (Section 5.4.3)
        nn.init.kaiming_uniform_(self.W_intra.weight, nonlinearity='relu')
        nn.init.kaiming_uniform_(self.W_inter.weight, nonlinearity='relu')
        nn.init.kaiming_uniform_(self.W_self.weight,  nonlinearity='relu')
        nn.init.zeros_(self.W_self.bias)

        self.bn = nn.BatchNorm1d(d_g) if use_bn else nn.Identity()
        self.dropout = nn.Dropout(dropout)

        if activation == "relu":
            self.act = nn.ReLU()
        elif activation == "gelu":
            self.act = nn.GELU()
        else:
            self.act = nn.ReLU()

    def _aggregate(
        self,
        H: torch.Tensor,
        edges: List[Tuple[int, int]],
        W: nn.Linear
    ) -> torch.Tensor:
        """
        Aggregate messages from src nodes to dst nodes
        using relation-specific weight W.

        Implements the inner sum in Eq. (17):
            sum_{j in N_r(i)} (1/|N_r(i)|) * W_r * h[j]

        Args:
            H:     (T, d_g) node embedding matrix
            edges: List of (src, dst) pairs for relation r
            W:     Relation-specific linear map

        Returns:
            agg: (T, d_g) aggregated messages
        """
        T = H.shape[0]
        agg = torch.zeros_like(H)
        cnt = torch.zeros(T, 1, device=H.device, dtype=H.dtype)

        if len(edges) == 0:
            return agg

        # Batch all edges for efficiency
        src_idx = torch.tensor([e[0] for e in edges],
                                dtype=torch.long, device=H.device)
        dst_idx = torch.tensor([e[1] for e in edges],
                                dtype=torch.long, device=H.device)

        msgs = W(H[src_idx])              # (E, d_g)
        agg.index_add_(0, dst_idx, msgs)  # scatter add to dst
        cnt.index_add_(0, dst_idx,
                       torch.ones(len(edges), 1, device=H.device))
        cnt = cnt.clamp(min=1.0)

        return agg / cnt

    def forward(
        self,
        H: torch.Tensor,
        intra_edges: List[Tuple[int, int]],
        inter_edges: List[Tuple[int, int]],
    ) -> torch.Tensor:
        """
        Single R-GCN message-passing step.

        Args:
            H:           (T, d_g) node embeddings
            intra_edges: R_intra edge list (src, dst)
            inter_edges: R_inter edge list (src, dst)

        Returns:
            g: (T, d_g) updated node embeddings
        """
        # Relation-specific aggregation
        agg_intra = self._aggregate(H, intra_edges, self.W_intra)
        agg_inter = self._aggregate(H, inter_edges, self.W_inter)

        # Self-loop + activation (Eq. 17)
        g = agg_intra + agg_inter + self.W_self(H)
        g = self.act(g)
        g = self.bn(g)
        g = self.dropout(g)

        return g


class RGCN(nn.Module):
    """
    Stacked R-GCN with L=2 layers (Table 6, Section 5.7).

    Gradient separation (Remark 2) holds across all layers:
    L_period updates W_{R_inter} in every layer without
    affecting W_{R_intra}.

    Args:
        d_g:       Graph embedding dimension (128)
        num_layers: Number of R-GCN layers (2)
        use_bn:    Batch normalisation flag
        dropout:   Dropout rate
    """

    def __init__(
        self,
        d_g: int = 128,
        num_layers: int = 2,
        use_bn: bool = True,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.layers = nn.ModuleList([
            RGCNLayer(d_g, use_bn, dropout)
            for _ in range(num_layers)
        ])
        self.num_layers = num_layers

    def forward(
        self,
        H: torch.Tensor,
        intra_edges: List[Tuple[int, int]],
        inter_edges: List[Tuple[int, int]],
    ) -> torch.Tensor:
        """
        Args:
            H:           (T, d_g) Pool3D node features
            intra_edges: R_intra edge list
            inter_edges: R_inter edge list

        Returns:
            g: (T, d_g) R-GCN output after L layers
        """
        for layer in self.layers:
            H = layer(H, intra_edges, inter_edges)
        return H
