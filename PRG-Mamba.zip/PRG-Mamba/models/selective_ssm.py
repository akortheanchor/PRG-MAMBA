"""
Selective State Space Model (Mamba-style)
==========================================
Implements the selective SSM from Section 5.4.3
(Eqs. 11-15). Processes an ordered sequence with
input-dependent gating (step size Delta_t).

Paper reference: PRG-Mamba, Section 5.4.3
Based on: Gu & Dao (2024), Mamba: Linear-time sequence
          modeling with selective state spaces.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from einops import rearrange


class SelectiveSSM(nn.Module):
    """
    Selective State Space Model with HiPPO initialisation.

    Operates on a sequence of node embeddings ordered by
    temporal index (Eq. 10: S(i) = sort_t({j: (i,j) in R_inter})).

    The input-dependent step size Delta_t (Eq. 11) selectively
    retains state from the lag matching the true HR and suppresses
    mismatched lags without softmax normalisation.

    Args:
        d_model: Input/output feature dimension (d_g = 128)
        N_state: SSM state dimension (N = 16)
        d_conv:  Local convolution width (4)
        expand:  Inner expansion factor (2)
        dt_min:  Minimum step size
        dt_max:  Maximum step size
        dt_init: Step size initialisation strategy
        hippo_init: Use HiPPO initialisation for A matrix
    """

    def __init__(
        self,
        d_model: int = 128,
        N_state: int = 16,
        d_conv: int = 4,
        expand: int = 2,
        dt_min: float = 0.001,
        dt_max: float = 0.1,
        dt_init: str = "random",
        dt_scale: float = 1.0,
        dt_init_floor: float = 1e-4,
        bias: bool = False,
        hippo_init: bool = True,
    ):
        super().__init__()
        self.d_model = d_model
        self.N_state = N_state
        self.d_conv = d_conv
        self.expand = expand
        self.d_inner = int(expand * d_model)

        # Input projection: d_model -> 2 * d_inner (x and z)
        self.in_proj = nn.Linear(d_model, 2 * self.d_inner, bias=bias)

        # Local causal convolution
        self.conv1d = nn.Conv1d(
            in_channels=self.d_inner,
            out_channels=self.d_inner,
            kernel_size=d_conv,
            groups=self.d_inner,
            padding=d_conv - 1,
            bias=True,
        )

        # SSM parameter projections
        # x_proj: d_inner -> dt_rank + 2 * N_state
        dt_rank = math.ceil(d_model / 16)
        self.dt_rank = dt_rank
        self.x_proj = nn.Linear(
            self.d_inner, dt_rank + 2 * N_state, bias=False
        )

        # dt_proj: dt_rank -> d_inner (step size projection)
        self.dt_proj = nn.Linear(dt_rank, self.d_inner, bias=True)

        # dt initialisation following Mamba paper
        dt_init_std = dt_rank ** -0.5 * dt_scale
        if dt_init == "constant":
            nn.init.constant_(self.dt_proj.weight, dt_init_std)
        elif dt_init == "random":
            nn.init.uniform_(self.dt_proj.weight, -dt_init_std, dt_init_std)

        # dt bias initialised to log(Uniform(dt_min, dt_max))
        dt = torch.exp(
            torch.rand(self.d_inner) * (math.log(dt_max) - math.log(dt_min))
            + math.log(dt_min)
        ).clamp(min=dt_init_floor)
        inv_dt = dt + torch.log(-torch.expm1(-dt))
        with torch.no_grad():
            self.dt_proj.bias.copy_(inv_dt)
        self.dt_proj.bias._no_reinit = True

        # A matrix: diagonal, initialised with HiPPO (Gu et al. 2020)
        # Eq. (12): A_bar_t = exp(Delta_t * A), A negative reals
        if hippo_init:
            # HiPPO-LegS: a_n = -(n + 0.5)
            A = -torch.arange(1, N_state + 1, dtype=torch.float32)
        else:
            A = -torch.ones(N_state, dtype=torch.float32)
        self.A_log = nn.Parameter(torch.log(-A))
        self.A_log._no_weight_decay = True

        # D matrix (skip connection scalar)
        self.D = nn.Parameter(torch.ones(self.d_inner))
        self.D._no_weight_decay = True

        # Output gate projection
        self.out_proj = nn.Linear(self.d_inner, d_model, bias=bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass over ordered inter-period neighbourhood sequence.

        Implements Eqs. (11)-(15):
          (11) Delta_t = softplus(g[j_t] · W_Delta + b_Delta)
          (12) A_bar_t = exp(Delta_t · A)
          (13) B_bar_t = Delta_t · (g[j_t] · W_B)
          (14) h_ssm[t] = A_bar_t ⊙ h_ssm[t-1] + B_bar_t
          (15) o[j_t] = g[j_t] + sigmoid(g[j_t]·W_G) ⊙ (h_ssm[t]·W_C)

        Args:
            x: (L, d_model) ordered sequence of R-GCN node embeddings

        Returns:
            out: (L, d_model) Graph Mamba refined embeddings
        """
        L, d = x.shape
        # Add batch dimension for layer ops
        x = x.unsqueeze(0)  # (1, L, d)

        # Input projection -> split into x_branch and gate z
        xz = self.in_proj(x)            # (1, L, 2*d_inner)
        x_branch, z = xz.chunk(2, dim=-1)  # each (1, L, d_inner)

        # Local causal convolution
        x_branch = rearrange(x_branch, 'b l d -> b d l')
        x_branch = self.conv1d(x_branch)[..., :L]
        x_branch = rearrange(x_branch, 'b d l -> b l d')
        x_branch = F.silu(x_branch)

        # SSM parameter computation
        x_dbl = self.x_proj(x_branch)   # (1, L, dt_rank + 2*N)
        dt, B, C = x_dbl.split(
            [self.dt_rank, self.N_state, self.N_state], dim=-1
        )

        # Step size Delta_t via softplus (Eq. 11)
        dt = F.softplus(self.dt_proj(dt))  # (1, L, d_inner)

        # A matrix (stable negative diagonal)
        A = -torch.exp(self.A_log.float())  # (N_state,)

        # Selective scan: compute SSM states sequentially
        # Implements Eqs. (12)-(14)
        out = self._selective_scan(x_branch, dt, A, B, C)

        # Output gate (Eq. 15): sigmoid gating + skip
        out = out * F.silu(z)
        out = self.out_proj(out)         # (1, L, d_model)

        return out.squeeze(0)            # (L, d_model)

    def _selective_scan(
        self,
        u: torch.Tensor,    # (1, L, d_inner)
        dt: torch.Tensor,   # (1, L, d_inner)
        A: torch.Tensor,    # (N_state,)
        B: torch.Tensor,    # (1, L, N_state)
        C: torch.Tensor,    # (1, L, N_state)
    ) -> torch.Tensor:
        """
        Sequential selective state-space scan.
        Implements Eqs. (12)-(14) for each time step t.
        """
        B_sz, L, d = u.shape
        N = A.shape[0]
        device = u.device

        # Discretise A and B (ZOH discretisation)
        # A_bar = exp(dt * A), B_bar = dt * B
        dt = dt.float()
        A = A.float()

        # A_bar: (1, L, d_inner, 1) × (N,) → (1, L, d_inner, N)
        dA = torch.exp(
            dt.unsqueeze(-1) * A.view(1, 1, 1, N)
        )  # (1, L, d_inner, N)

        # B_bar: (1, L, d_inner, 1) × (1, L, 1, N) → (1, L, d_inner, N)
        dB = dt.unsqueeze(-1) * B.unsqueeze(2)  # (1, L, d_inner, N)

        # Sequential state update
        h = torch.zeros(B_sz, d, N, device=device, dtype=u.dtype)
        ys = []
        for t in range(L):
            # Eq. (14): h[t] = A_bar[t] ⊙ h[t-1] + B_bar[t] * u[t]
            h = dA[:, t] * h + dB[:, t] * u[:, t].unsqueeze(-1)
            # y[t] = C[t] · h[t]
            y = (h * C[:, t].unsqueeze(1)).sum(-1)  # (1, d_inner)
            ys.append(y)

        y = torch.stack(ys, dim=1)   # (1, L, d_inner)
        # Skip connection (D matrix)
        y = y + u * self.D.unsqueeze(0).unsqueeze(0)
        return y
