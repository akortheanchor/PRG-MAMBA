"""
Adaptive Skin-Tone Equalisation (ASTE) — OctaAug Component 8
=============================================================
Implements Section 4.8, Eqs. (30)-(34):
  Beer-Lambert amplitude model for melanin-dependent BVP suppression.
  ITA-based melanin estimation.
  Spatially non-uniform amplitude rescaling.

Theorem 2 (Section 4.8): BVP amplitude preserved as
  A_tilde_BVP = alpha_G * A_BVP (Eq. 33).
"""

import cv2
import numpy as np
from typing import Optional
from omegaconf import DictConfig


class AdaptiveSkinToneEqualisation:
    """
    Simulate melanin-induced BVP amplitude variation across
    Fitzpatrick groups I-VI by blending frame intensities
    toward the estimated target melanin level.

    Args:
        cfg: aste config block from default.yaml
    """

    # Channel-specific melanin absorption coefficients (cm^-1)
    # at RGB peak wavelengths: 610nm, 550nm, 450nm (Eq. 32)
    MU_A = {'R': 0.8, 'G': 1.7, 'B': 3.1}
    ELL  = 0.15   # effective optical path length (cm)

    def __init__(self, cfg: DictConfig):
        self.prob      = cfg.prob
        self.delta_cm  = cfg.delta_cm      # ±0.15 max shift
        self.ita_slope = cfg.ita_slope     # 0.43

    def _ita_to_cm(self, L_star: float, b_star: float) -> float:
        """
        Compute melanin volume fraction c_m from ITA (Eq. 31).

        ITA = arctan((L* - 50) / b*) * 180/pi
        c_m = 0.43 * (1 - ITA/90)
        """
        ita = np.degrees(np.arctan2(L_star - 50.0, b_star + 1e-8))
        c_m = self.ita_slope * (1.0 - ita / 90.0)
        return float(np.clip(c_m, 0.01, 0.43))

    def _estimate_cm(
        self,
        clip: np.ndarray,
        skin_roi: Optional[np.ndarray] = None
    ) -> float:
        """
        Estimate source melanin concentration from frame average.

        Args:
            clip:     (T, H, W, 3) float32 [0,1]
            skin_roi: (H, W) binary mask (optional)

        Returns:
            c_m_src: estimated melanin concentration
        """
        # Use mean of first 5 frames for stability
        frame_mean = clip[:5].mean(axis=0)  # (H, W, 3)

        # Convert to uint8 for OpenCV CIELAB conversion
        frame_u8  = (frame_mean * 255).clip(0, 255).astype(np.uint8)
        frame_lab = cv2.cvtColor(frame_u8, cv2.COLOR_RGB2LAB)
        frame_lab = frame_lab.astype(np.float32)

        # L* in [0,100], b* in [-127,127] after OpenCV scaling
        L_star = frame_lab[..., 0] * 100.0 / 255.0
        b_star = frame_lab[..., 2] - 128.0

        if skin_roi is not None:
            mask    = skin_roi.astype(bool)
            L_mean  = L_star[mask].mean() if mask.any() else L_star.mean()
            b_mean  = b_star[mask].mean() if mask.any() else b_star.mean()
        else:
            L_mean = L_star.mean()
            b_mean = b_star.mean()

        return self._ita_to_cm(L_mean, b_mean)

    def _alpha(self, c_m: float) -> np.ndarray:
        """
        Compute per-channel blending coefficient alpha_c (Eq. 30).

        alpha_c = exp(-c_m * mu_a^(c) * ell)

        Returns:
            (3,) array [alpha_R, alpha_G, alpha_B]
        """
        alphas = np.array([
            np.exp(-c_m * self.MU_A['R'] * self.ELL),
            np.exp(-c_m * self.MU_A['G'] * self.ELL),
            np.exp(-c_m * self.MU_A['B'] * self.ELL),
        ], dtype=np.float32)
        return alphas

    def __call__(
        self,
        clip: np.ndarray,
        skin_roi: Optional[np.ndarray] = None
    ) -> np.ndarray:
        """
        Apply ASTE to a video clip.

        Implements Eq. (29):
          f_tilde_t^(c) = alpha_c * f_t^(c) + (1-alpha_c) * f_bar_skin^(c)

        Args:
            clip:     (T, H, W, 3) float32 [0,1]
            skin_roi: (H, W) binary mask (optional)

        Returns:
            clip_aug: (T, H, W, 3) float32 [0,1]
        """
        if np.random.rand() > self.prob:
            return clip

        T, H, W, C = clip.shape

        # Estimate source melanin level
        c_m_src = self._estimate_cm(clip, skin_roi)

        # Sample target melanin (±delta_cm, clamped to [0.01, 0.43])
        c_m_tgt = float(np.clip(
            c_m_src + np.random.uniform(-self.delta_cm, self.delta_cm),
            0.01, 0.43
        ))

        # Per-channel blending coefficients
        alpha_src = self._alpha(c_m_src)    # (3,)
        alpha_tgt = self._alpha(c_m_tgt)    # (3,)
        alpha_rel = alpha_tgt / (alpha_src + 1e-8)  # relative shift

        # Mean skin-pixel intensity per channel (Eq. 29 DC term)
        if skin_roi is not None and skin_roi.any():
            mask = skin_roi.astype(bool)
            f_bar = clip.mean(axis=0)[mask].mean(axis=0)  # (3,)
        else:
            f_bar = clip.mean(axis=(0, 1, 2))             # (3,)

        # Apply blending: Eq. (29)
        clip_aug = (
            alpha_rel[np.newaxis, np.newaxis, np.newaxis, :] * clip
            + (1.0 - alpha_rel)[np.newaxis, np.newaxis, np.newaxis, :]
            * f_bar[np.newaxis, np.newaxis, np.newaxis, :]
        )

        return np.clip(clip_aug, 0.0, 1.0)
