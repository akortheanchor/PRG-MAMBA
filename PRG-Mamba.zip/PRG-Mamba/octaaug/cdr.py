"""
Chromatic Domain Randomisation (CDR) — OctaAug Component 4
===========================================================
Implements Section 4.4, Eqs. (6)-(9):

  f_tilde_t = clip([0,1])(A_CDR · f_t + b_CDR)
  A_CDR     = A_wb · A_ccm · A_sat

where:
  A_wb:  white-balance gain diag(w_R, w_G, w_B), w_c ~ U(0.75, 1.30)
  A_ccm: colour correction matrix perturbation I + ε·E_off
  A_sat: saturation scale (1-s)·1·v_lum^T + s·I, s ~ U(0.70, 1.30)

Proposition 1 (Section 4.4): BVP peak attenuation bounded in [0.75, 1.30].

Whitelist: w_B/w_G ≤ 1.60 to protect Fitzpatrick V-VI contrast.

Paper reference: PRG-Mamba, Section 4.4
"""

import numpy as np
from omegaconf import DictConfig


# ITU-R BT.709 luminance weights v_lum (Eq. 9)
V_LUM = np.array([0.2126, 0.7152, 0.0722], dtype=np.float32)


class ChromaticDomainRandomisation:
    """
    Simulate illuminant spectrum shifts across camera types and
    lighting conditions (LED, incandescent, NIR, daylight).

    Applied uniformly across all T frames — BVP temporal structure
    is preserved (Proposition 1, Section 4.4).

    Args:
        cfg: cdr config block from default.yaml
    """

    def __init__(self, cfg: DictConfig):
        self.prob       = float(cfg.prob)
        self.wb_range   = list(cfg.wb_range)
        self.ccm_eps    = float(cfg.ccm_eps)
        self.sat_range  = list(cfg.sat_range)
        self.bias_range = list(cfg.bias_range)
        self.wb_blue_cap = float(cfg.wb_blue_cap)  # w_B/w_G ≤ 1.60

    def _sample_wb(self) -> np.ndarray:
        """
        White-balance diagonal matrix A_wb (Eq. 7).
        Enforces w_B/w_G ≤ wb_blue_cap for Fitzpatrick V-VI protection.
        """
        w = np.random.uniform(*self.wb_range, size=3).astype(np.float32)
        # Clamp blue/green ratio
        if w[2] / (w[1] + 1e-8) > self.wb_blue_cap:
            w[2] = self.wb_blue_cap * w[1]
        return np.diag(w)   # (3, 3)

    def _sample_ccm(self) -> np.ndarray:
        """
        Camera CCM uncertainty: A_ccm = I + ε·E_off (Eq. 8).
        Off-diagonal elements only — preserves diagonal dominance.
        """
        E    = np.random.randn(3, 3).astype(np.float32)
        np.fill_diagonal(E, 0.0)               # zero diagonal
        A    = np.eye(3, dtype=np.float32) + self.ccm_eps * E
        return A

    def _sample_sat(self) -> np.ndarray:
        """
        Saturation scale matrix A_sat (Eq. 9):
          A_sat = (1-s)·1·v_lum^T + s·I
        """
        s = float(np.random.uniform(*self.sat_range))
        A = (1.0 - s) * np.outer(np.ones(3, dtype=np.float32), V_LUM)
        A = A + s * np.eye(3, dtype=np.float32)
        return A

    def _sample_bias(self) -> np.ndarray:
        """Per-channel additive bias b_CDR (Section 4.4)."""
        return np.random.uniform(*self.bias_range, size=3).astype(np.float32)

    def __call__(self, clip: np.ndarray) -> np.ndarray:
        """
        Apply CDR to a video clip.

        Implements Eq. (6): f_tilde_t = clip([0,1])(A_CDR·f_t + b_CDR)

        Same (A_CDR, b_CDR) is applied to all T frames, preserving
        BVP temporal structure (Proposition 1).

        Args:
            clip: (T, H, W, 3) float32 [0, 1]

        Returns:
            clip_aug: (T, H, W, 3) float32 [0, 1]
        """
        if np.random.rand() > self.prob:
            return clip

        # Sample transformation (once per clip)
        A_wb  = self._sample_wb()
        A_ccm = self._sample_ccm()
        A_sat = self._sample_sat()
        A_cdr = A_wb @ A_ccm @ A_sat   # (3, 3) — Eq. (6)
        b_cdr = self._sample_bias()    # (3,)

        T, H, W, C = clip.shape
        flat    = clip.reshape(-1, 3)           # (T*H*W, 3)
        flat_t  = (flat @ A_cdr.T) + b_cdr     # broadcast bias
        out     = np.clip(flat_t, 0.0, 1.0)    # Eq. (6) clip
        return out.reshape(T, H, W, C).astype(np.float32)

    def bvp_attenuation_bound(self, w_min: float = 0.75,
                               w_max: float = 1.30) -> tuple:
        """
        Proposition 1: BVP peak attenuation factor bound.
        Returns (lower_bound, upper_bound) = (w_min, w_max).
        """
        return (w_min, w_max)
