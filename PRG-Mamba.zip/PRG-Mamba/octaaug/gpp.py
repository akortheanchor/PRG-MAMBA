"""
Geometric Pose Perturbation (GPP) — OctaAug Component 6
=========================================================
Implements Section 4.6, Eqs. (1)-(4):
  T_theta = T_flip ∘ T_scale ∘ T_trans ∘ T_rot

Clip-level identical transformation preserves BVP
temporal structure (Proposition 2, Eq. 3).

ROI rejection: drops clips where transformed face
occupies < 40% of original ROI area (Eq. 5).
"""

import cv2
import numpy as np
from typing import Tuple, Optional
from omegaconf import DictConfig


class GeometricPosePerturbation:
    """
    Apply clip-level spatial transformation to simulate
    head pose variation (rotation, translation, scale, flip).

    The SAME parameter vector theta is applied to all T frames
    to preserve BVP temporal structure (Proposition 2).

    Args:
        cfg: gpp config block from default.yaml
    """

    def __init__(self, cfg: DictConfig):
        self.prob         = cfg.prob
        self.rot_range    = cfg.rot_range         # degrees
        self.trans_range  = cfg.trans_range       # fraction of W
        self.scale_range  = cfg.scale_range
        self.flip_prob    = cfg.flip_prob
        self.roi_thresh   = cfg.roi_area_threshold

    def _sample_params(self, W: int) -> dict:
        """Sample transformation parameter vector theta."""
        return {
            'angle': np.random.uniform(*self.rot_range),
            'tx':    np.random.uniform(*self.trans_range) * W,
            'ty':    np.random.uniform(*self.trans_range) * W,
            'scale': np.random.uniform(*self.scale_range),
            'flip':  np.random.rand() < self.flip_prob,
        }

    def _apply_frame(
        self,
        frame: np.ndarray,
        params: dict,
        H: int,
        W: int
    ) -> np.ndarray:
        """Apply transformation to a single frame (H, W, 3)."""
        cx, cy = W / 2.0, H / 2.0

        # Rotation + scale about centre
        M = cv2.getRotationMatrix2D(
            (cx, cy), params['angle'], params['scale']
        )
        # Translation
        M[0, 2] += params['tx']
        M[1, 2] += params['ty']

        frame = cv2.warpAffine(frame, M, (W, H),
                                flags=cv2.INTER_LINEAR,
                                borderMode=cv2.BORDER_REFLECT_101)
        if params['flip']:
            frame = cv2.flip(frame, 1)
        return frame

    def _roi_overlap(
        self,
        orig_frame: np.ndarray,
        trans_frame: np.ndarray
    ) -> float:
        """
        Estimate ROI overlap as fraction of non-black pixels
        retained after transformation (proxy for Eq. 5).
        """
        orig_mask  = (orig_frame.sum(-1) > 0.01).astype(np.float32)
        trans_mask = (trans_frame.sum(-1) > 0.01).astype(np.float32)
        intersection = (orig_mask * trans_mask).sum()
        union = orig_mask.sum()
        return float(intersection / (union + 1e-8))

    def __call__(
        self,
        clip: np.ndarray,
        skin_roi: Optional[np.ndarray] = None
    ) -> Tuple[np.ndarray, bool]:
        """
        Apply GPP to a video clip.

        Args:
            clip:     (T, H, W, 3) float32 [0,1]
            skin_roi: unused, for API compatibility

        Returns:
            transformed clip (T, H, W, 3)
            valid: bool — False if ROI overlap < threshold
        """
        if np.random.rand() > self.prob:
            return clip, True

        T, H, W, C = clip.shape
        params = self._sample_params(W)

        transformed = np.stack([
            self._apply_frame(clip[t], params, H, W)
            for t in range(T)
        ], axis=0)

        # ROI retention check (Eq. 5)
        overlap = self._roi_overlap(clip[0], transformed[0])
        valid   = overlap >= self.roi_thresh

        return transformed, valid
