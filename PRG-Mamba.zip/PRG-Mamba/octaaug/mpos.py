"""
Multi-Scale Plane-Orthogonal-to-Skin (MPOS) — OctaAug Component 3
===================================================================
Implements Section 4.3, Eq. (3):

  X_MPOS = Concat(G(X_POS, k) : k ∈ {7, 15, 31})

where X_POS = P^T · Norm(C) is the POS skin-orthogonal projection.

Gaussian kernel sizes {7, 15, 31} span one octave between pairs
(7→15 ≈ 2.1×, 15→31 ≈ 2.1×), covering:
  k=7  : fine capillary texture     (ρ = 5.5% of frame width)
  k=15 : dominant cheek/forehead    (ρ = 11.7% of frame width)
  k=31 : global illumination ref.   (ρ = 24.2% of frame width)

Paper reference: PRG-Mamba, Section 4.3
Based on: Wang et al. (2017), Algorithmic Principles of
          Remote PPG (POS method).
"""

import cv2
import numpy as np
from omegaconf import DictConfig


# POS skin-orthogonal projection matrix P ∈ R^{3×2}
# Calibrated under daylight illumination (Wang et al. 2017)
POS_MATRIX = np.array([
    [ 0,  1, -1],
    [-2,  1,  1],
], dtype=np.float32)   # shape (2, 3); applied as P^T * x = (3,) → (2,)


class MultiScaleMPOS:
    """
    Multi-scale POS projection with three Gaussian spatial scales.

    Produces a 6-channel output per frame:
      2 POS channels × 3 kernel sizes = 6 channels

    Args:
        cfg: mpos config block with kernel_sizes, prob
    """

    def __init__(self, cfg: DictConfig):
        self.prob         = float(getattr(cfg, 'prob', 1.0))
        self.kernel_sizes = list(getattr(cfg, 'kernel_sizes', [7, 15, 31]))
        # Ensure all kernels are odd
        self.kernel_sizes = [k if k % 2 == 1 else k + 1
                             for k in self.kernel_sizes]

    def _pos_project(self, frame_norm: np.ndarray) -> np.ndarray:
        """
        Apply POS projection to a single normalised frame.

        Implements X_POS = P^T · Norm(C).

        Args:
            frame_norm: (H, W, 3) frame with mean-normalised channels

        Returns:
            pos: (H, W, 2) POS-projected frame
        """
        H, W, _ = frame_norm.shape
        flat = frame_norm.reshape(-1, 3)   # (H*W, 3)
        pos  = flat @ POS_MATRIX.T         # (H*W, 2)
        return pos.reshape(H, W, 2)

    def _temporal_norm(self, clip: np.ndarray) -> np.ndarray:
        """
        Temporal mean normalisation per channel:
          f_norm = f / mean_t(f)  − 1

        Args:
            clip: (T, H, W, 3) float32

        Returns:
            normalised clip (T, H, W, 3)
        """
        mu   = clip.mean(axis=0, keepdims=True)  # (1, H, W, 3)
        norm = clip / (mu + 1e-8) - 1.0
        return norm.astype(np.float32)

    def _gaussian_blur(self, img: np.ndarray, k: int) -> np.ndarray:
        """Apply Gaussian blur with kernel size k × k."""
        # OpenCV GaussianBlur: (H, W, C) float32
        blurred = cv2.GaussianBlur(img, (k, k), 0)
        return blurred

    def __call__(self, clip: np.ndarray) -> np.ndarray:
        """
        Compute multi-scale MPOS for a video clip.

        Implements Eq. (3):
          X_MPOS = Concat(G(X_POS, k) : k ∈ {7, 15, 31})

        Args:
            clip: (T, H, W, 3) float32 [0, 1]

        Returns:
            mpos: (T, H, W, 6) multi-scale POS features
                  (2 channels × 3 scales)
        """
        T, H, W, _ = clip.shape

        # Step 1: Temporal mean normalisation
        norm_clip = self._temporal_norm(clip)  # (T, H, W, 3)

        # Step 2: Per-frame POS projection and multi-scale Gaussian blur
        all_scales = []
        for k in self.kernel_sizes:
            scale_frames = []
            for t in range(T):
                pos_t    = self._pos_project(norm_clip[t])  # (H, W, 2)
                blurred  = self._gaussian_blur(pos_t, k)    # (H, W, 2)
                scale_frames.append(blurred)
            all_scales.append(
                np.stack(scale_frames, axis=0)  # (T, H, W, 2)
            )

        # Step 3: Concatenate scales along channel dimension
        mpos = np.concatenate(all_scales, axis=-1)  # (T, H, W, 6)

        return mpos.astype(np.float32)

    def coverage_ratios(self, W: int = 128) -> dict:
        """
        Compute ρ_k = k/W for each kernel size.
        Reports spatial frequency coverage (Section 4.3).
        """
        return {f'k={k}': round(k / W * 100, 1)
                for k in self.kernel_sizes}
