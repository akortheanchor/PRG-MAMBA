"""
Normalised Difference Frames (NDF) — OctaAug Component 2
=========================================================
Implements Section 4.2, Eq. (2):

  X_NDF_t = (f_{t+1} - f_t) / (f_{t+1} + f_t + ε)

Amplifies BVP-driven reflectance transients while suppressing
global illumination drift — a normalised analogue of CHROM.

NDF is invariant to:
  - CDR bias term b_CDR (cancels in frame difference)
  - ASTE multiplicative scaling α_c (cancels in normalised ratio)

This three-way CDR + ASTE + NDF interaction (Section 7.3.3)
ensures NDF provides a stable chromatic and amplitude-invariant
BVP channel regardless of augmentation combinations.

Paper reference: PRG-Mamba, Sections 4.2, 7.3.3
"""

import numpy as np
from omegaconf import DictConfig


class NormalisedDifferenceFrames:
    """
    Compute normalised frame differences for all consecutive pairs.

    NDF is always active (prob=1.0) and applied after GPP, TRR,
    CDR, ASTE, and TCM in the OctaAug pipeline, operating on
    correctly resampled and geometrically stable frames.

    Args:
        cfg: ndf config block with epsilon
    """

    def __init__(self, cfg: DictConfig):
        self.eps  = float(getattr(cfg, 'epsilon', 1e-6))
        self.prob = float(getattr(cfg, 'prob', 1.0))

    def __call__(self, clip: np.ndarray) -> np.ndarray:
        """
        Compute NDF for a video clip.

        Implements Eq. (2):
          X_NDF_t = (f_{t+1} - f_t) / (f_{t+1} + f_t + ε)

        Args:
            clip: (T, H, W, 3) float32 [0, 1]

        Returns:
            ndf: (T-1, H, W, 3) normalised difference frames
        """
        f_next = clip[1:]   # f_{t+1}: (T-1, H, W, 3)
        f_curr = clip[:-1]  # f_t    : (T-1, H, W, 3)

        ndf = (f_next - f_curr) / (f_next + f_curr + self.eps)

        return ndf.astype(np.float32)

    def illumination_invariance_check(
        self,
        clip: np.ndarray,
        scale: float = 2.0
    ) -> float:
        """
        Verify illumination invariance: NDF should be invariant to
        uniform multiplicative illumination scaling.

        For clip_scaled = scale * clip:
          NDF_scaled = NDF (exactly, since scale cancels in ratio)

        Args:
            clip:  (T, H, W, 3) float32
            scale: Illumination scale factor

        Returns:
            max_diff: Maximum absolute difference (should be ~0)
        """
        clip_scaled = np.clip(clip * scale, 0.0, 1.0)
        ndf_orig    = self(clip)
        ndf_scaled  = self(clip_scaled)
        return float(np.abs(ndf_orig - ndf_scaled).max())
