"""
Physiological Band-Selective Masking (PBSM) — OctaAug Component 5
==================================================================
Implements Section 4.5, Eqs. (11)-(14):

  S_tilde(f) = S(f)·M(f) + ξ(f)·(1−M(f))
  M(f) = 0  if f_mask ≤ |f| < f_mask + B_mask
         1  otherwise

f_mask  ~ U(0.6, 3.4) Hz,  B_mask ~ U(0.10, 0.40) Hz
Safety margin 0.10 Hz around f̂₀ = HR/60.
Disabled at epoch 1 (HR estimate unreliable).

Theorem 1 (Section 4.5, Eq. 14):
  SNR(s̃, f₀) ≥ SNR(ŝ, f₀) + η_dB > 0
  whenever ‖η_{f_η}‖² > σ_ξ² · B_mask.

Paper reference: PRG-Mamba, Section 4.5
"""

import numpy as np
from omegaconf import DictConfig


class PhysiologicalBandSelectiveMasking:
    """
    Apply randomised frequency-domain mask within the cardiac band,
    forcing the model to reconstruct masked frequencies from context.

    The cardiac-safe constraint guarantees f₀ is never masked:
    mask is rejected and resampled if it falls within 0.10 Hz of
    the estimated BVP fundamental f̂₀ (Remark 1, Section 4.5).

    Args:
        cfg: pbsm config block from default.yaml
        fs:  Reference frame rate (30 fps)
    """

    def __init__(self, cfg: DictConfig, fs: float = 30.0):
        self.prob           = float(cfg.prob)
        self.f_min          = float(cfg.f_min)          # 0.6 Hz
        self.f_max          = float(cfg.f_max)          # 3.4 Hz
        self.b_min          = float(cfg.b_min)          # 0.10 Hz
        self.b_max          = float(cfg.b_max)          # 0.40 Hz
        self.safety_margin  = float(cfg.safety_margin)  # 0.10 Hz
        self.disable_epoch1 = bool(cfg.disable_epoch1)
        self.fs             = fs

    def _sample_mask(self, f0_hz: float,
                     max_tries: int = 20) -> tuple:
        """
        Sample mask parameters with cardiac-safe constraint (Remark 1).

        Returns:
            (f_mask, B_mask) or None if valid mask not found
        """
        for _ in range(max_tries):
            f_mask = np.random.uniform(self.f_min, self.f_max)
            B_mask = np.random.uniform(self.b_min, self.b_max)

            # Ensure mask end stays within band
            if f_mask + B_mask > self.f_max + 0.1:
                continue

            # Cardiac-safe: f0 must be outside mask with safety margin
            lo = f_mask - self.safety_margin
            hi = f_mask + B_mask + self.safety_margin
            if lo <= f0_hz <= hi:
                continue

            return f_mask, B_mask

        return None, None   # fallback: no valid mask found

    def __call__(
        self,
        bvp: np.ndarray,
        hr_est: float,
        epoch: int = 2,
    ) -> np.ndarray:
        """
        Apply PBSM to a BVP signal estimate.

        Implements Eqs. (11)-(12):
          S_tilde(f) = S(f)·M(f) + ξ(f)·(1−M(f))

        Args:
            bvp:    (T,) float32 intermediate BVP estimate
            hr_est: Estimated HR in bpm (for f0 safety margin)
            epoch:  Current training epoch (disable at epoch 1)

        Returns:
            bvp_aug: (T,) float32 frequency-masked BVP signal
        """
        # Epoch 1 disable (Section 4.5, Remark 1)
        if self.disable_epoch1 and epoch <= 1:
            return bvp

        if np.random.rand() > self.prob:
            return bvp

        T   = len(bvp)
        f0  = max(hr_est, 40.0) / 60.0   # Hz — estimated BVP fundamental

        # Sample cardiac-safe mask
        f_mask, B_mask = self._sample_mask(f0)
        if f_mask is None:
            return bvp   # fallback: no valid mask, skip

        # Compute DTFT
        n_fft = max(T * 4, 512)
        freqs  = np.fft.rfftfreq(n_fft, d=1.0 / self.fs)
        S      = np.fft.rfft(bvp, n=n_fft)     # complex spectrum

        # Build binary mask M(f) — Eq. (12)
        M      = np.ones(len(freqs), dtype=np.float32)
        mask_b = (freqs >= f_mask) & (freqs < f_mask + B_mask)
        M[mask_b] = 0.0

        # Matched-power noise (σ_ξ² = E[|S(f)|²])
        sigma_xi  = np.sqrt(np.mean(np.abs(S) ** 2))
        xi        = (np.random.randn(len(freqs))
                     + 1j * np.random.randn(len(freqs)))
        xi       *= sigma_xi / (np.sqrt(2) + 1e-8)

        # Eq. (11): S_tilde = S·M + ξ·(1−M)
        S_tilde   = S * M + xi * (1.0 - M)

        # Inverse FFT → time domain, truncate to T
        bvp_aug   = np.fft.irfft(S_tilde, n=n_fft)[:T]
        bvp_aug   = bvp_aug.astype(np.float32)

        # Normalise (NPCC loss is amplitude-invariant, Eq. 22)
        std       = bvp_aug.std()
        if std > 1e-6:
            bvp_aug = (bvp_aug - bvp_aug.mean()) / std

        return bvp_aug

    def snr_gain_lower_bound(
        self,
        eta_power: float,
        sigma_xi_sq: float,
        B_mask: float
    ) -> float:
        """
        Theorem 1 SNR gain lower bound (Eq. 14):
          η_dB = 10·log₁₀(‖η_{f_η}‖² / (σ_ξ² · B_mask))

        Returns dB improvement when interference power > replacement noise.
        """
        if eta_power <= sigma_xi_sq * B_mask:
            return 0.0   # No gain when interference ≤ noise power
        return 10.0 * np.log10(eta_power / (sigma_xi_sq * B_mask + 1e-12))
