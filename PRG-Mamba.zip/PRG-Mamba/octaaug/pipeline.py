"""
OctaAug: Eight-Component Augmentation Pipeline
================================================
Applies all eight augmentation components in the
physiologically motivated order specified in
Table 2 (Section 4.1):

  GPP → TRR → CDR → ASTE → TCM → NDF → MPOS → PBSM

The ordering ensures:
  1. Geometric/temporal transforms (GPP, TRR) before
     signal-level transforms (NDF computes frame differences
     on already-resampled, geometrically stable frames)
  2. Chromatic/amplitude transforms (CDR, ASTE) before
     spectral masking (PBSM masks BVP-estimate frequencies,
     which must first be chromatically normalised)
  3. PBSM disabled at epoch 1 (Section 4.5, Remark 1)

Paper reference: PRG-Mamba, Sections 4.1-4.8, Eq. (26)
"""

import torch
import numpy as np
from typing import Dict, Tuple, Optional
from omegaconf import DictConfig

from octaaug.gpp  import GeometricPosePerturbation
from octaaug.trr  import TemporalResolutionResampling
from octaaug.cdr  import ChromaticDomainRandomisation
from octaaug.aste import AdaptiveSkinToneEqualisation
from octaaug.tcm  import TemporalCutMix
from octaaug.ndf  import NormalisedDifferenceFrames
from octaaug.mpos import MultiScaleMPOS
from octaaug.pbsm import PhysiologicalBandSelectiveMasking


class OctaAug:
    """
    Orchestrates all eight OctaAug components in pipeline order.

    Args:
        cfg:   OctaAug config block (from configs/default.yaml)
        fs:    Reference frame rate (default 30)
        epoch: Current training epoch (for PBSM epoch-1 disable)
    """

    def __init__(self, cfg: DictConfig, fs: float = 30.0):
        self.cfg = cfg
        self.fs  = fs

        # Instantiate all eight components
        self.gpp  = GeometricPosePerturbation(cfg.gpp)
        self.trr  = TemporalResolutionResampling(cfg.trr, fs)
        self.cdr  = ChromaticDomainRandomisation(cfg.cdr)
        self.aste = AdaptiveSkinToneEqualisation(cfg.aste)
        self.tcm  = TemporalCutMix(cfg.tcm)
        self.ndf  = NormalisedDifferenceFrames(cfg.ndf)
        self.mpos = MultiScaleMPOS(cfg.mpos)
        self.pbsm = PhysiologicalBandSelectiveMasking(cfg.pbsm, fs)

    def __call__(
        self,
        clip: np.ndarray,
        bvp: np.ndarray,
        hr_gt: float,
        epoch: int = 1,
        clip2: Optional[np.ndarray] = None,
        bvp2: Optional[np.ndarray] = None,
        skin_roi: Optional[np.ndarray] = None,
        training: bool = True,
    ) -> Dict:
        """
        Apply full OctaAug pipeline to one video clip.

        Application order (Table 2, Section 4.1):
          GPP → TRR → CDR → ASTE → TCM → NDF → MPOS → PBSM

        Args:
            clip:     (T, H, W, 3) uint8 RGB video clip [0, 255]
            bvp:      (T,) float32 ground-truth BVP signal
            hr_gt:    Ground-truth heart rate in bpm
            epoch:    Current training epoch
            clip2:    Second clip for TCM mixing (optional)
            bvp2:     Second BVP for TCM label mixing (optional)
            skin_roi: (H, W) binary mask of skin region (optional)
            training: If False, skip stochastic augmentations

        Returns:
            dict with keys:
              'streams':  dict of 8 augmented feature streams
              'bvp':      (T,) augmented BVP label
              'hr':       float augmented HR label
              'fps_eff':  effective frame rate after TRR
              'delta_trr': recalibrated inter-period lag after TRR
        """
        # Normalise clip to [0, 1]
        clip_f = clip.astype(np.float32) / 255.0
        T, H, W, _ = clip_f.shape

        bvp_aug = bvp.copy()
        hr_aug  = float(hr_gt)
        fps_eff = self.fs
        delta_trr = int(round(self.fs * 60.0 / max(hr_aug, 40.0)))

        streams = {}

        # ── Step 1: GPP — Geometric Pose Perturbation (Sec 4.6) ─────
        if training:
            clip_f, valid = self.gpp(clip_f, skin_roi)
            if not valid:
                # ROI overlap < 0.40: skip augmentation for this clip
                clip_f = clip.astype(np.float32) / 255.0

        streams['gpp'] = clip_f.copy()

        # ── Step 2: TRR — Temporal Resolution Resampling (Sec 4.7) ──
        if training:
            clip_f, bvp_aug, fps_eff, delta_trr = self.trr(
                clip_f, bvp_aug, hr_aug
            )
        streams['trr'] = clip_f.copy()

        # ── Step 3: CDR — Chromatic Domain Randomisation (Sec 4.4) ──
        if training:
            clip_f = self.cdr(clip_f)
        streams['cdr'] = clip_f.copy()

        # ── Step 4: ASTE — Adaptive Skin-Tone Equalisation (Sec 4.8)─
        if training:
            clip_f = self.aste(clip_f, skin_roi)
        streams['aste'] = clip_f.copy()

        # ── Step 5: TCM — Temporal CutMix (Sec 4.1) ─────────────────
        if training and clip2 is not None and bvp2 is not None:
            clip_f, bvp_aug, hr_aug = self.tcm(
                clip_f, bvp_aug, hr_aug,
                clip2.astype(np.float32) / 255.0,
                bvp2, hr_gt
            )
        streams['tcm'] = clip_f.copy()

        # ── Step 6: NDF — Normalised Difference Frames (Sec 4.2) ─────
        # Returns (T-1, H, W, 3); we zero-pad to (T, H, W, 3)
        ndf_out = self.ndf(clip_f)                              # (T-1,H,W,3)
        ndf_out = np.concatenate([ndf_out[:1], ndf_out], axis=0)# (T,H,W,3)
        streams['ndf'] = ndf_out

        # ── Step 7: MPOS — Multi-Scale MPOS (Sec 4.3) ───────────────
        mpos_out = self.mpos(clip_f)  # (T, H, W, 6): 3 scales × 2 channels
        streams['mpos'] = mpos_out

        # ── Step 8: PBSM — Physiological Band-Selective Mask (Sec 4.5)
        if training and epoch > 1:
            bvp_aug = self.pbsm(bvp_aug, hr_aug)
        streams['pbsm'] = bvp_aug.copy()

        return {
            'streams'  : streams,
            'bvp'      : bvp_aug,
            'hr'       : hr_aug,
            'fps_eff'  : fps_eff,
            'delta_trr': delta_trr,
        }

    def fuse_streams(
        self,
        streams: Dict,
        T: int,
        H: int,
        W: int
    ) -> torch.Tensor:
        """
        Concatenate all 8 streams and produce Conv3D input tensor.

        Implements Eq. (26): C_in = 3+T+6+3+1+3+3+3 = 23+T channels
        Output is projected to d=192 by Conv3D in the model.

        Args:
            streams: Dict of augmented feature arrays
            T, H, W: Clip spatial-temporal dimensions

        Returns:
            Z_concat: (C_in, T, H, W) tensor ready for Conv3D
        """
        parts = []

        # TCM:  (T, H, W, 3) → (3, T, H, W)
        tcm = torch.from_numpy(
            streams['tcm'].transpose(3, 0, 1, 2)).float()
        parts.append(tcm)

        # NDF:  (T, H, W, 3) → (3, T, H, W) → reshape to (T, H, W, 3)
        ndf = torch.from_numpy(
            streams['ndf'].transpose(3, 0, 1, 2)).float()
        parts.append(ndf)

        # MPOS: (T, H, W, 6) → (6, T, H, W)
        mpos = torch.from_numpy(
            streams['mpos'].transpose(3, 0, 1, 2)).float()
        parts.append(mpos)

        # CDR:  (T, H, W, 3) → (3, T, H, W)
        cdr = torch.from_numpy(
            streams['cdr'].transpose(3, 0, 1, 2)).float()
        parts.append(cdr)

        # PBSM: (T,) → broadcast to (1, T, H, W)
        pbsm_sig = torch.from_numpy(streams['pbsm']).float()
        pbsm = pbsm_sig.view(1, T, 1, 1).expand(1, T, H, W)
        parts.append(pbsm)

        # GPP:  (T, H, W, 3) → (3, T, H, W)
        gpp = torch.from_numpy(
            streams['gpp'].transpose(3, 0, 1, 2)).float()
        parts.append(gpp)

        # TRR:  (T, H, W, 3) → (3, T, H, W)
        trr = torch.from_numpy(
            streams['trr'].transpose(3, 0, 1, 2)).float()
        parts.append(trr)

        # ASTE: (T, H, W, 3) → (3, T, H, W)
        aste = torch.from_numpy(
            streams['aste'].transpose(3, 0, 1, 2)).float()
        parts.append(aste)

        return torch.cat(parts, dim=0)  # (23+T, T, H, W) but T=3 dims above
