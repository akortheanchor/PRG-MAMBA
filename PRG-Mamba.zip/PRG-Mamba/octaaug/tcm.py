"""
Temporal CutMix (TCM) — OctaAug Component 1
=============================================
Implements Section 4.1, Eq. (1):

  C_tilde_t = C2_t  if s ≤ t < s+L
              C1_t  otherwise
  y_tilde   = (1-λ)·y1 + λ·y2,  λ = L/T

Fourier-domain guarantee (Appendix A, Eq. A.4):
  Attenuates dominant BVP peak by (T-L)/T via Dirichlet kernel.

Paper reference: PRG-Mamba, Sections 4.1, Appendix A
Based on: Yun et al. (2019), CutMix: Training Strategy
          that Makes Use of Sample Mixing.
"""

import numpy as np
from typing import Tuple
from omegaconf import DictConfig


class TemporalCutMix:
    """
    Replaces a contiguous temporal segment of clip1 with clip2.

    The same transformation is applied to the BVP label,
    producing a mixed label y_tilde = (1-λ)*y1 + λ*y2.

    The Fourier proof (Appendix A) shows this acts as convolution
    with a Dirichlet kernel, attenuating the BVP peak by (T-L)/T.

    Args:
        cfg: tcm config block with prob, ratio_range
    """

    def __init__(self, cfg: DictConfig):
        self.prob        = cfg.prob
        self.ratio_range = list(cfg.ratio_range)

    def __call__(
        self,
        clip1:  np.ndarray,
        bvp1:   np.ndarray,
        hr1:    float,
        clip2:  np.ndarray,
        bvp2:   np.ndarray,
        hr2:    float,
    ) -> Tuple[np.ndarray, np.ndarray, float]:
        """
        Apply Temporal CutMix to (clip1, bvp1) using (clip2, bvp2).

        Args:
            clip1: (T, H, W, 3) float32 [0,1] — source clip
            bvp1:  (T,) float32  — source BVP
            hr1:   float         — source HR (bpm)
            clip2: (T, H, W, 3) float32 [0,1] — donor clip
            bvp2:  (T,) float32  — donor BVP
            hr2:   float         — donor HR (bpm)

        Returns:
            clip_aug: (T, H, W, 3) mixed clip
            bvp_aug:  (T,) mixed BVP label
            hr_aug:   float mixed HR label
        """
        if np.random.rand() > self.prob:
            return clip1, bvp1, hr1

        T = clip1.shape[0]

        # Sample replacement length L and start position s
        r = np.random.uniform(*self.ratio_range)
        L = int(round(r * T))
        L = max(1, min(L, T - 1))
        s = np.random.randint(0, T - L + 1)

        lam = L / T   # mixing coefficient λ

        # Apply temporal mask (Eq. 1)
        clip_aug         = clip1.copy()
        bvp_aug          = bvp1.copy()
        clip_aug[s:s+L]  = clip2[s:s+L]
        bvp_aug[s:s+L]   = bvp2[s:s+L]

        # Soft label mixing
        hr_aug = (1 - lam) * hr1 + lam * hr2

        return clip_aug, bvp_aug, float(hr_aug)

    def peak_attenuation(self, T: int, L: int) -> float:
        """
        Closed-form BVP peak attenuation (Appendix A, Eq. A.4):
          |X_tilde(ω1)| / |X1(ω1)| ≈ (T - L) / T

        Args:
            T: Clip length in frames
            L: Replaced segment length in frames

        Returns:
            attenuation factor in (0, 1)
        """
        return (T - L) / T
