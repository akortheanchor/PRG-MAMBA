"""
Temporal Resolution Resampling (TRR) — OctaAug Component 7
===========================================================
Implements Section 4.7, Eqs. (27)-(28):
  Simulate multi-framerate environments by subsampling/upsampling
  clips to fps* in {20,24,25,30,50,60} fps then restoring to 30fps.

  After TRR, inter-period lag is recalibrated (Eq. 28):
    delta_TRR = floor(fps* * 60 / HR_est)

This exposes W_{R_inter} to lags from 6 to 90 frames during
training, covering the full physiological + framerate space.
"""

import numpy as np
from scipy.interpolate import interp1d
from typing import Tuple
from omegaconf import DictConfig


class TemporalResolutionResampling:
    """
    Bidirectional temporal resampling augmentation.

    Subsample clip to fps* then upsample back to reference fps,
    simulating the aliasing and lag-space shift of different cameras.

    Args:
        cfg: trr config block from default.yaml
        fs:  Reference frame rate (30 fps default)
    """

    def __init__(self, cfg: DictConfig, fs: float = 30.0):
        self.prob        = cfg.prob
        self.target_fps  = list(cfg.target_fps)
        self.ref_fps     = float(cfg.reference_fps)
        self.interp_mode = getattr(cfg, 'interpolation', 'linear')

    def _resample_clip(
        self,
        clip: np.ndarray,
        fps_src: float,
        fps_tgt: float
    ) -> np.ndarray:
        """
        Temporally resample clip from fps_src to fps_tgt.

        For fps_tgt < fps_src: drop frames (subsampling).
        For fps_tgt > fps_src: interpolate frames (upsampling).

        Args:
            clip:    (T, H, W, 3) float32
            fps_src: source frame rate
            fps_tgt: target frame rate

        Returns:
            resampled clip with T frames at fps_tgt
        """
        T, H, W, C = clip.shape
        t_src = np.linspace(0, 1, T)
        t_tgt = np.linspace(0, 1, T)  # Keep T fixed, change effective fps

        if abs(fps_src - fps_tgt) < 0.5:
            return clip.copy()

        # Actual number of frames at fps_tgt covering same duration
        T_tgt = max(4, int(round(T * fps_tgt / fps_src)))

        t_src_pts = np.linspace(0, T - 1, T)
        t_tgt_pts = np.linspace(0, T - 1, T_tgt)

        # Interpolate each spatial position over time
        clip_flat = clip.reshape(T, -1)   # (T, H*W*C)
        interp    = interp1d(t_src_pts, clip_flat, axis=0,
                             kind=self.interp_mode,
                             fill_value='extrapolate')
        resampled = interp(t_tgt_pts)    # (T_tgt, H*W*C)
        resampled = resampled.reshape(T_tgt, H, W, C)

        # Restore to T frames (upsample or downsample back to T)
        t_tgt2 = np.linspace(0, T_tgt - 1, T_tgt)
        t_ref  = np.linspace(0, T_tgt - 1, T)
        interp2 = interp1d(t_tgt2, resampled.reshape(T_tgt, -1),
                           axis=0, kind=self.interp_mode,
                           fill_value='extrapolate')
        restored = interp2(t_ref).reshape(T, H, W, C)

        return np.clip(restored, 0.0, 1.0).astype(np.float32)

    def _resample_bvp(
        self,
        bvp: np.ndarray,
        fps_src: float,
        fps_tgt: float
    ) -> np.ndarray:
        """Resample BVP signal identically to clip (Eq. 27)."""
        T = len(bvp)
        if abs(fps_src - fps_tgt) < 0.5:
            return bvp.copy()

        T_tgt = max(4, int(round(T * fps_tgt / fps_src)))
        t_src = np.linspace(0, T - 1, T)
        t_mid = np.linspace(0, T - 1, T_tgt)
        t_ref = np.linspace(0, T_tgt - 1, T)

        mid = interp1d(t_src, bvp, kind=self.interp_mode,
                       fill_value='extrapolate')(t_mid)
        restored = interp1d(np.linspace(0, T_tgt - 1, T_tgt), mid,
                            kind=self.interp_mode,
                            fill_value='extrapolate')(t_ref)
        return restored.astype(np.float32)

    def compute_delta_trr(self, fps_eff: float, hr_est: float) -> int:
        """
        Compute recalibrated inter-period lag for effective fps.

        Implements Eq. (28):
          delta_TRR = floor(fps* * 60 / HR_est)

        Args:
            fps_eff: effective frame rate after TRR
            hr_est:  estimated HR in bpm

        Returns:
            delta_trr in frames (clamped to [6, 90])
        """
        hr_safe = max(hr_est, 40.0)
        delta   = int(np.floor(fps_eff * 60.0 / hr_safe))
        return int(np.clip(delta, 6, 90))

    def __call__(
        self,
        clip: np.ndarray,
        bvp: np.ndarray,
        hr_est: float
    ) -> Tuple[np.ndarray, np.ndarray, float, int]:
        """
        Apply TRR to clip and BVP signal.

        Args:
            clip:   (T, H, W, 3) float32 [0,1]
            bvp:    (T,) float32 BVP signal
            hr_est: estimated HR in bpm

        Returns:
            clip_aug:  (T, H, W, 3) resampled clip
            bvp_aug:   (T,) resampled BVP
            fps_eff:   effective frame rate used
            delta_trr: recalibrated inter-period lag (frames)
        """
        if np.random.rand() > self.prob:
            delta = self.compute_delta_trr(self.ref_fps, hr_est)
            return clip, bvp, self.ref_fps, delta

        fps_tgt = float(np.random.choice(self.target_fps))
        clip_aug = self._resample_clip(clip, self.ref_fps, fps_tgt)
        bvp_aug  = self._resample_bvp(bvp,  self.ref_fps, fps_tgt)
        delta    = self.compute_delta_trr(fps_tgt, hr_est)

        return clip_aug, bvp_aug, fps_tgt, delta
