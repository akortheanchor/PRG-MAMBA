"""
Cross-Attention Fusion Gate
============================
Implements Section 5.5.1, Eqs. (18)-(21):

  Z_cat  = [Z_RGCN || Z_Mamba]               (Eq. 18)
  alpha  = sigmoid(W_g * Z_cat + b_g)        (Eq. 19)
  Z_fused = alpha * Z_RGCN + (1-alpha)*Z_Mamba (Eq. 20)
  Z_tilde = Dropout(LN(Z_fused))             (Eq. 21)

Gate values lie in (0.30, 0.70) per node (Section 7.1.2),
confirming both pathways contribute at every frame:
  - Gate favours R-GCN during stationary segments
  - Gate favours Graph Mamba during motion-corrupted frames

Paper reference: PRG-Mamba, Section 5.5.1
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class CrossAttentionFusion(nn.Module):
    """
    Sigmoid-gated fusion of R-GCN and Graph Mamba outputs.

    Args:
        d_g:     Graph embedding dimension (128)
        dropout: Dropout rate applied after fusion (0.10)
    """

    def __init__(self, d_g: int = 128, dropout: float = 0.10):
        super().__init__()
        # W_g: (d_g*2 → d_g) — gate weight matrix
        self.W_gate  = nn.Linear(d_g * 2, d_g, bias=True)
        self.dropout = nn.Dropout(dropout)
        self.ln      = nn.LayerNorm(d_g)

        nn.init.xavier_uniform_(self.W_gate.weight)
        nn.init.zeros_(self.W_gate.bias)

    def forward(
        self,
        Z_rgcn:  torch.Tensor,
        Z_mamba: torch.Tensor,
    ) -> torch.Tensor:
        """
        Fuse R-GCN and Graph Mamba node embeddings.

        Args:
            Z_rgcn:  (T, d_g) R-GCN output
            Z_mamba: (T, d_g) Graph Mamba SSM output

        Returns:
            Z_tilde: (T, d_g) fused, normalised, dropout-regularised
        """
        # Eq. 18: concatenate along feature dimension
        Z_cat = torch.cat([Z_rgcn, Z_mamba], dim=-1)   # (T, 2*d_g)

        # Eq. 19: input-dependent gate
        alpha   = torch.sigmoid(self.W_gate(Z_cat))    # (T, d_g) in (0,1)

        # Eq. 20: weighted interpolation
        Z_fused = alpha * Z_rgcn + (1.0 - alpha) * Z_mamba  # (T, d_g)

        # Eq. 21: LayerNorm + Dropout
        Z_tilde = self.dropout(self.ln(Z_fused))

        return Z_tilde

    def gate_statistics(self, Z_rgcn, Z_mamba):
        """
        Compute gate value statistics for interpretability.
        Returns mean and std of alpha across all nodes and dims.
        """
        with torch.no_grad():
            Z_cat = torch.cat([Z_rgcn, Z_mamba], dim=-1)
            alpha = torch.sigmoid(self.W_gate(Z_cat))
        return {
            'alpha_mean': float(alpha.mean()),
            'alpha_std':  float(alpha.std()),
            'alpha_min':  float(alpha.min()),
            'alpha_max':  float(alpha.max()),
        }
