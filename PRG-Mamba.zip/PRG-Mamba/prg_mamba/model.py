"""
PRG-Mamba: Complete Model
==========================
Full pipeline integrating all six stages (Algorithm 1):

  Stage 0: OctaAug (Section 4)
  Stage 1: Swin Transformer (Section 5.2)
  Stage 2: Pool3D Spatial Gate (Section 5.2)
  Stage 3: Periodic Graph G=(V,E,R) (Section 5.3)
  Stage 4: R-GCN + Graph Mamba (Section 5.4)
  Stage 5: Cross-Attention Fusion + Conv1D Decoder (Section 5.5)
  Stage 6: Blockchain Audit (Section 5.6)

Paper reference: PRG-Mamba, Algorithm 1 (Section 5.7)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Optional, Tuple

from prg_mamba.swin_encoder import SwinEncoder
from prg_mamba.pool3d import Pool3DGate
from prg_mamba.fusion import CrossAttentionFusion
from models.graph_construction import PeriodicGraphBuilder
from models.rgcn import RGCN
from models.selective_ssm import SelectiveSSM
from models.graph_mamba import GraphMambaEncoder
from losses.composite import CompositeLoss
from blockchain.audit import BlockchainAudit


class PRGMamba(nn.Module):
    """
    Periodic Relational Graph-Mamba for contactless HR estimation.

    Implements the complete forward pass from Algorithm 1 (Section 5.7):
      Z_0 = OctaAug_fuse(...)          # from pipeline, passed in
      z_t = SwinEncoder(Z_0)
      h[t] = Pool3D(z_t)
      G    = build_graph(h, delta_trr)
      bvp, fused, g = GraphMambaEncoder(h, G)
      B_k  = Blockchain(bvp, metadata)

    Args:
        cfg_model:     model config block from default.yaml
        fs:            Reference frame rate (30 fps)
        use_blockchain: Enable blockchain audit layer
    """

    def __init__(self, cfg_model, fs: float = 30.0,
                 use_blockchain: bool = True):
        super().__init__()
        self.fs = fs
        self.d_g = cfg_model.pool3d.d_g

        # Stage 1: Swin Transformer encoder
        self.swin = SwinEncoder(cfg_model.swin)

        # Stage 2: Pool3D spatial commitment gate (Eq. 2)
        self.pool3d = Pool3DGate(
            d_in=cfg_model.pool3d.d_in,
            d_g=cfg_model.pool3d.d_g
        )

        # Stage 3: Periodic graph builder (reusable across batches)
        self.graph_builder = PeriodicGraphBuilder(
            T=128,
            fs=fs,
            P=cfg_model.graph.P,
            F=cfg_model.graph.F,
            hr_min=cfg_model.graph.hr_range[0],
            hr_max=cfg_model.graph.hr_range[1],
        )
        self.cfg_graph = cfg_model.graph

        # Stage 4: R-GCN + Graph Mamba encoder
        self.gm_encoder = GraphMambaEncoder(
            d_g=cfg_model.pool3d.d_g,
            N_state=cfg_model.graph_mamba.N_state,
            kernel_size=cfg_model.decoder.kernel_size,
            dropout=cfg_model.fusion.dropout,
        )

        # Stage 6: Blockchain audit (optional)
        self.use_blockchain = use_blockchain
        if use_blockchain:
            self.blockchain = BlockchainAudit()

    def forward(
        self,
        Z0: torch.Tensor,
        hr_est: Optional[float] = None,
        delta_trr: Optional[int] = None,
        training: bool = True,
        metadata: Optional[Dict] = None,
    ) -> Dict:
        """
        Full PRG-Mamba forward pass (Algorithm 1).

        Args:
            Z0:        (B, C_in, T, H, W) OctaAug fused embedding
            hr_est:    Estimated HR in bpm (for graph construction)
            delta_trr: TRR-recalibrated inter-period lag (frames)
            training:  Training mode flag
            metadata:  Dict for blockchain audit (device, timestamp, etc.)

        Returns:
            Dict with keys:
              bvp_pred  : (T,) predicted BVP signal
              hr_pred   : float predicted HR (bpm)
              fused_emb : (T, d_g) Graph Mamba fused embeddings
              rgcn_emb  : (T, d_g) R-GCN embeddings (gradient routing)
              block     : blockchain block B_k (if enabled)
        """
        B, C, T, H, W = Z0.shape
        assert B == 1, "PRG-Mamba processes one clip at a time"

        # ── Stage 1: Swin encoder ─────────────────────────────────────
        # Z0: (1, C_in, T, H, W) → z_feat: (T, H', W', d_swin)
        z_feat = self.swin(Z0.squeeze(0))

        # ── Stage 2: Pool3D gate ──────────────────────────────────────
        # z_feat: (T, H', W', d_swin) → H_nodes: (T, d_g)
        H_nodes = self.pool3d(z_feat)          # (T, d_g)

        # ── Stage 3: Build Temporal-Periodic Graph ────────────────────
        device = H_nodes.device
        use_train_range = training

        intra_ei, inter_ei, intra_list, inter_list = \
            self.graph_builder.build(
                hr_est=hr_est,
                train=use_train_range,
                device=str(device),
            )

        # If TRR recalibrated delta, override inter edges
        if delta_trr is not None and delta_trr != self.graph_builder.T:
            from models.graph_construction import (
                build_intra_edges, build_inter_edges
            )
            intra_list = build_intra_edges(
                T, self.cfg_graph.P, self.cfg_graph.F
            )
            inter_list = build_inter_edges(
                T,
                delta_min=max(6, delta_trr - 3),
                delta_max=min(90, delta_trr + 3),
                hr_est=hr_est,
                fs=self.fs,
                train=use_train_range,
            )

        # ── Stage 4: R-GCN + Graph Mamba ─────────────────────────────
        # H_nodes: (T, d_g) → bvp_pred: (T,), fused: (T,d_g), g: (T,d_g)
        bvp_pred, fused_emb, rgcn_emb = self.gm_encoder(
            H_nodes, intra_list, inter_list
        )

        # ── HR estimation from predicted BVP ─────────────────────────
        bvp_np  = bvp_pred.detach().cpu().numpy()
        from evaluation.metrics import compute_hr_from_bvp
        hr_pred = compute_hr_from_bvp(bvp_np, self.fs)

        # ── Stage 6: Blockchain audit ─────────────────────────────────
        block = None
        if self.use_blockchain and not training:
            meta = metadata or {}
            block = self.blockchain.commit(
                bvp_signal=bvp_np,
                hr_pred=hr_pred,
                metadata=meta,
            )

        return {
            'bvp_pred'  : bvp_pred,
            'hr_pred'   : hr_pred,
            'fused_emb' : fused_emb,
            'rgcn_emb'  : rgcn_emb,
            'block'     : block,
        }
