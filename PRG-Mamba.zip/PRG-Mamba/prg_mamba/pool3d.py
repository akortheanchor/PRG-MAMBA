"""
Pool3D Spatial Commitment Gate
================================
Implements Section 5.2, Eq. (2):
  h[t] = Pool3D(z_t) ∈ R^{d_g}

Globally pools Swin spatial features before temporal graph.
By epoch 20, Swin attention is predominantly confined to
forehead/cheeks (Section 5.2.2); Pool3D locks this spatial
prior into each graph node, preventing background leakage.

Also computes spatial attention metrics (Section 5.2.2):
  H(A): Shannon entropy (Eq. 7)
  Psi:  attention sharpness (Eq. 8)
  rho:  physiological ROI ratio (Eq. 9)

Paper reference: PRG-Mamba, Section 5.2
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple


class Pool3DGate(nn.Module):
    """
    Spatial commitment gate: global average pool over H×W
    followed by a linear projection to graph embedding space.

    Args:
        d_in: Swin Stage-4 output channels (8C = 768 for Swin-Tiny)
        d_g:  Graph embedding dimension (128)
    """

    def __init__(self, d_in: int = 768, d_g: int = 128):
        super().__init__()
        self.d_in = d_in
        self.d_g  = d_g

        self.proj = nn.Linear(d_in, d_g, bias=True)
        self.ln   = nn.LayerNorm(d_g)

        nn.init.kaiming_uniform_(self.proj.weight, nonlinearity='linear')
        nn.init.zeros_(self.proj.bias)

    def forward(
        self,
        z: torch.Tensor,
        return_attn_metrics: bool = False
    ) -> torch.Tensor:
        """
        Args:
            z: (T, H', W', d_in) Swin Stage-4 spatial features

        Returns:
            H_nodes: (T, d_g) globally pooled + projected node features
        """
        T, Hp, Wp, d = z.shape

        # Global average pooling over spatial dimensions H', W'
        pooled = z.mean(dim=(1, 2))     # (T, d_in)

        # Project to graph dimension and normalise
        h = self.ln(self.proj(pooled))  # (T, d_g)
        return h

    def attention_entropy(self, attn_map: torch.Tensor) -> float:
        """
        Shannon entropy of attention map (Eq. 7):
          H(A) = -sum_i a_i * log(a_i)

        Args:
            attn_map: (H', W') normalised attention weights

        Returns:
            entropy in nats
        """
        a = attn_map.flatten()
        a = a / (a.sum() + 1e-8)
        entropy = -(a * (a + 1e-12).log()).sum()
        return float(entropy)

    def roi_ratio(
        self,
        attn_map: torch.Tensor,
        roi_mask: torch.Tensor
    ) -> float:
        """
        Physiological ROI attention ratio (Eq. 9):
          rho = sum_{i in Omega_phys} A_i / sum_{j in G} A_j

        Args:
            attn_map: (H', W') attention weights
            roi_mask: (H', W') binary physiological ROI mask

        Returns:
            rho in [0, 1]
        """
        total = attn_map.sum().item()
        phys  = (attn_map * roi_mask.float()).sum().item()
        return phys / (total + 1e-8)
