"""
Swin Transformer Spatial Encoder
==================================
Wraps timm Swin Transformer as the spatial encoding
backbone (Section 5.2, Eq. 1).

W-MSA with learnable relative-position bias:
  W-MSA(Q,K,V) = softmax(QK^T / sqrt(d_k) + B) V    (Eq. 1)

Stage-4 output (8C channels) is passed to Pool3D gate.
Pre-trained ImageNet weights are loaded when available.

Paper reference: PRG-Mamba, Section 5.2
Based on: Liu et al. (2021), Swin Transformer.
"""

import torch
import torch.nn as nn
from typing import Optional


class SwinEncoder(nn.Module):
    """
    Swin Transformer backbone for per-frame spatial feature extraction.

    Processes each of the T frames independently, producing
    Stage-4 spatial features that Pool3D then collapses per frame.

    Args:
        cfg: swin config block with fields:
             embed_dim, depths, num_heads, window_size,
             drop_path_rate, pretrained, pretrained_ckpt
    """

    def __init__(self, cfg):
        super().__init__()
        try:
            import timm
            self.backbone = timm.create_model(
                'swin_tiny_patch4_window7_224',
                pretrained=getattr(cfg, 'pretrained', False),
                num_classes=0,           # remove classifier head
                global_pool='',          # keep spatial feature maps
                drop_path_rate=getattr(cfg, 'drop_path_rate', 0.1),
            )
            self.d_out = self.backbone.num_features   # 768 for swin_tiny
        except ImportError:
            # Fallback: lightweight placeholder for testing without timm
            self.backbone = _SimpleSpatialEncoder(
                in_ch=3,
                d_out=getattr(cfg, 'embed_dim', 96) * 8
            )
            self.d_out = getattr(cfg, 'embed_dim', 96) * 8

        self.d_embed = getattr(cfg, 'embed_dim', 96)

    def forward(self, clip: torch.Tensor) -> torch.Tensor:
        """
        Extract spatial features from all T frames.

        Args:
            clip: (T, C_in, H, W)  — single clip, no batch dim

        Returns:
            features: (T, H', W', d_out)  Swin Stage-4 output
        """
        T = clip.shape[0]

        # Process each frame independently through Swin
        # Swin expects (B, C, H, W); we treat T as the batch
        feats = self.backbone.forward_features(clip)  # (T, H'*W', d_out)

        # Reshape from sequence back to spatial
        # Swin_tiny at 128×128 input → Stage-4: (T, 16, d_out) approx
        # Exact H', W' depends on input resolution
        seq_len = feats.shape[1]
        Hp = Wp = int(seq_len ** 0.5)
        feats = feats.view(T, Hp, Wp, feats.shape[-1])  # (T, H', W', d)

        return feats


class _SimpleSpatialEncoder(nn.Module):
    """
    Lightweight fallback encoder for testing without timm.
    Produces correct output shape but without pre-training.
    """

    def __init__(self, in_ch: int = 3, d_out: int = 768):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_ch, 64,  3, 2, 1), nn.GELU(),
            nn.Conv2d(64,  128,  3, 2, 1), nn.GELU(),
            nn.Conv2d(128, 256,  3, 2, 1), nn.GELU(),
            nn.Conv2d(256, d_out, 3, 1, 1), nn.GELU(),
        )
        self.d_out = d_out

    def forward_features(self, x: torch.Tensor) -> torch.Tensor:
        """x: (T, C, H, W) → (T, H'*W', d_out)"""
        T = x.shape[0]
        out  = self.net(x)             # (T, d_out, H', W')
        T, d, Hp, Wp = out.shape
        out  = out.permute(0, 2, 3, 1) # (T, H', W', d)
        return out.reshape(T, Hp * Wp, d)
