"""
Ablation Study Runner
======================
Reproduces all ablation experiments from Section 6.6:

  Table 9  (inter-period ablation): Graph with/without R_inter
  Table 10 (Graph Mamba vs GT):     R-GCN+GM vs R-GCN+GT vs R-GCN only
  Table 11 (OctaAug cumulative):    TriAug → PentaAug → OctaAug
  Table 12 (lambda3 sensitivity):   lambda3 in {0,0.05,0.10,0.20,0.50,1.00}
  Table 13 (windowing):             [P,F,Delta] combinations

Usage:
  python scripts/ablation.py --config configs/mmpd.yaml --study octaaug
  python scripts/ablation.py --config configs/mmpd.yaml --study graph
  python scripts/ablation.py --config configs/mmpd.yaml --study all
"""

import os
import sys
import json
import argparse
import numpy as np
import torch
from omegaconf import OmegaConf, DictConfig

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from scripts.train import train, set_seed
from evaluation.metrics import compute_hr_metrics


ABLATION_CONFIGS = {

    # ── OctaAug cumulative ablation (Table 11) ────────────────────────
    'octaaug': [
        ('No augmentation',
         {'octaaug': {
             'tcm': {'prob': 0.0}, 'ndf': {'prob': 0.0},
             'mpos': {'prob': 0.0}, 'cdr': {'prob': 0.0},
             'pbsm': {'prob': 0.0}, 'gpp': {'prob': 0.0},
             'trr': {'prob': 0.0}, 'aste': {'prob': 0.0},
         }}),
        ('+TCM',
         {'octaaug': {
             'tcm': {'prob': 0.40}, 'ndf': {'prob': 0.0},
             'mpos': {'prob': 0.0}, 'cdr': {'prob': 0.0},
             'pbsm': {'prob': 0.0}, 'gpp': {'prob': 0.0},
             'trr': {'prob': 0.0}, 'aste': {'prob': 0.0},
         }}),
        ('+TCM +NDF',
         {'octaaug': {
             'tcm': {'prob': 0.40}, 'ndf': {'prob': 1.0},
             'mpos': {'prob': 0.0}, 'cdr': {'prob': 0.0},
             'pbsm': {'prob': 0.0}, 'gpp': {'prob': 0.0},
             'trr': {'prob': 0.0}, 'aste': {'prob': 0.0},
         }}),
        ('+TCM +NDF +MPOS (TriAug)',
         {'octaaug': {
             'tcm': {'prob': 0.40}, 'ndf': {'prob': 1.0},
             'mpos': {'prob': 1.0}, 'cdr': {'prob': 0.0},
             'pbsm': {'prob': 0.0}, 'gpp': {'prob': 0.0},
             'trr': {'prob': 0.0}, 'aste': {'prob': 0.0},
         }}),
        ('+CDR (PentaAug-4)',
         {'octaaug': {
             'tcm': {'prob': 0.40}, 'ndf': {'prob': 1.0},
             'mpos': {'prob': 1.0}, 'cdr': {'prob': 0.50},
             'pbsm': {'prob': 0.0}, 'gpp': {'prob': 0.0},
             'trr': {'prob': 0.0}, 'aste': {'prob': 0.0},
         }}),
        ('+CDR +PBSM (PentaAug)',
         {'octaaug': {
             'tcm': {'prob': 0.40}, 'ndf': {'prob': 1.0},
             'mpos': {'prob': 1.0}, 'cdr': {'prob': 0.50},
             'pbsm': {'prob': 0.35}, 'gpp': {'prob': 0.0},
             'trr': {'prob': 0.0}, 'aste': {'prob': 0.0},
         }}),
        ('+GPP',
         {'octaaug': {
             'tcm': {'prob': 0.40}, 'ndf': {'prob': 1.0},
             'mpos': {'prob': 1.0}, 'cdr': {'prob': 0.50},
             'pbsm': {'prob': 0.35}, 'gpp': {'prob': 0.45},
             'trr': {'prob': 0.0}, 'aste': {'prob': 0.0},
         }}),
        ('+GPP +TRR',
         {'octaaug': {
             'tcm': {'prob': 0.40}, 'ndf': {'prob': 1.0},
             'mpos': {'prob': 1.0}, 'cdr': {'prob': 0.50},
             'pbsm': {'prob': 0.35}, 'gpp': {'prob': 0.45},
             'trr': {'prob': 0.40}, 'aste': {'prob': 0.0},
         }}),
        ('+GPP +TRR +ASTE (OctaAug)',
         {'octaaug': {
             'tcm': {'prob': 0.40}, 'ndf': {'prob': 1.0},
             'mpos': {'prob': 1.0}, 'cdr': {'prob': 0.50},
             'pbsm': {'prob': 0.35}, 'gpp': {'prob': 0.45},
             'trr': {'prob': 0.40}, 'aste': {'prob': 0.50},
         }}),
    ],

    # ── Graph Mamba vs GT ablation (Table 10) ─────────────────────────
    'graph': [
        ('R-GCN only (no Mamba/GT)',
         {'model': {'graph_mamba': {'enabled': False},
                    'graph_transformer': {'enabled': False}}}),
        ('R-GCN + Graph Transformer',
         {'model': {'graph_mamba': {'enabled': False},
                    'graph_transformer': {'enabled': True}}}),
        ('R-GCN + Graph Mamba (Full)',
         {'model': {'graph_mamba': {'enabled': True},
                    'graph_transformer': {'enabled': False}}}),
    ],

    # ── Lambda3 sensitivity (Table 12) ────────────────────────────────
    'lambda3': [
        (f'lambda3={v}', {'loss': {'lambda3': v}})
        for v in [0.0, 0.05, 0.10, 0.20, 0.50, 1.00]
    ],

    # ── Windowing sensitivity (Table 13) ──────────────────────────────
    'window': [
        ('P only',         {'model': {'graph': {'P': 3, 'F': 0}},
                            'octaaug': {'trr': {'prob': 0.0}}}),
        ('F only',         {'model': {'graph': {'P': 0, 'F': 3}},
                            'octaaug': {'trr': {'prob': 0.0}}}),
        ('P+F only',       {'model': {'graph': {'P': 3, 'F': 3}},
                            'octaaug': {'trr': {'prob': 0.0}}}),
        ('Delta only',     {'model': {'graph': {'P': 0, 'F': 0}},
                            'octaaug': {'trr': {'prob': 0.40}}}),
        ('P+Delta',        {'model': {'graph': {'P': 3, 'F': 0}},
                            'octaaug': {'trr': {'prob': 0.40}}}),
        ('F+Delta',        {'model': {'graph': {'P': 0, 'F': 3}},
                            'octaaug': {'trr': {'prob': 0.40}}}),
        ('P+F+Delta (Full)', {'model': {'graph': {'P': 5, 'F': 5}},
                              'octaaug': {'trr': {'prob': 0.40}}}),
    ],
}


def run_ablation(cfg, study: str, output_dir: str, seed: int = 42):
    """Run one ablation study and print results table."""
    configs = ABLATION_CONFIGS.get(study, [])
    if not configs:
        print(f"Unknown study: {study}. "
              f"Choose from {list(ABLATION_CONFIGS.keys())}")
        return

    print(f"\n{'═'*60}")
    print(f"Ablation: {study.upper()} on {cfg.dataset.name}")
    print(f"{'═'*60}")
    print(f"{'Configuration':<35} {'MAE':>7} {'RMSE':>7} {'r':>7}")
    print(f"{'─'*60}")

    results = []
    for name, overrides in configs:
        run_cfg = OmegaConf.merge(cfg, OmegaConf.create(overrides))
        metrics = train(run_cfg, seed=seed)
        results.append((name, metrics))
        print(f"  {name:<33} {metrics['mae']:>7.3f} "
              f"{metrics['rmse']:>7.3f} {metrics['r']:>7.4f}")

    # Save
    os.makedirs(output_dir, exist_ok=True)
    out_path = os.path.join(output_dir, f'ablation_{study}.json')
    with open(out_path, 'w') as f:
        json.dump(
            [{'name': n, **m} for n, m in results],
            f, indent=2
        )
    print(f"\nSaved to {out_path}")
    return results


def main():
    parser = argparse.ArgumentParser(description='PRG-Mamba Ablation Study')
    parser.add_argument('--config', type=str, required=True)
    parser.add_argument('--study',  type=str, default='all',
                        choices=['octaaug', 'graph', 'lambda3',
                                 'window', 'all'])
    parser.add_argument('--output', type=str, default='results/ablations')
    parser.add_argument('--seed',   type=int, default=42)
    args = parser.parse_args()

    base_cfg    = OmegaConf.load('configs/default.yaml')
    dataset_cfg = OmegaConf.load(args.config)
    cfg         = OmegaConf.merge(base_cfg, dataset_cfg)

    studies = (
        list(ABLATION_CONFIGS.keys())
        if args.study == 'all' else [args.study]
    )
    for study in studies:
        run_ablation(cfg, study, args.output, args.seed)


if __name__ == '__main__':
    main()
