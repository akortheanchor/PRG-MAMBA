"""
Cross-Dataset Transfer Evaluation
====================================
Evaluates a model trained on one dataset and tested on another
without fine-tuning. Reproduces Table 9 (Section 6.4).

All six transfer directions evaluated:
  PURE   → UBFC-rPPG
  UBFC   → PURE
  MMPD   → PURE
  MMPD   → UBFC-rPPG
  VIPL   → MMPD
  MMPD   → VIPL

Usage:
  python scripts/cross_dataset.py \
    --train_config configs/mmpd.yaml \
    --test_config  configs/ubfc.yaml \
    --checkpoint   results/checkpoints/mmpd_best.pth
"""

import os
import sys
import json
import argparse
import numpy as np
import torch
from torch.utils.data import DataLoader
from omegaconf import OmegaConf
from tqdm import tqdm

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from prg_mamba.model import PRGMamba
from evaluation.metrics import compute_hr_metrics, compute_hr_from_bvp
from evaluation.bland_altman import bland_altman, print_bland_altman_summary
from evaluation.statistical_tests import wilcoxon_test


def cross_evaluate(
    train_cfg,
    test_cfg,
    ckpt_path: str,
    output_path: str = None,
):
    """
    Evaluate a model checkpoint on a different dataset (zero-shot transfer).

    Args:
        train_cfg:  Config of the training dataset (model architecture)
        test_cfg:   Config of the test dataset
        ckpt_path:  Checkpoint path from training
        output_path: Optional JSON output path

    Returns:
        Dict of evaluation metrics
    """
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # ── Load model (trained on train_cfg dataset) ─────────────────────
    # Use train_cfg model architecture but test_cfg frame rate
    model = PRGMamba(
        train_cfg.model,
        fs=test_cfg.dataset.fps,
        use_blockchain=False,
    ).to(device)

    ckpt = torch.load(ckpt_path, map_location=device)
    model.load_state_dict(ckpt['state_dict'])
    model.eval()

    train_ds_name = train_cfg.dataset.name
    test_ds_name  = test_cfg.dataset.name
    print(f"\nCross-Dataset: {train_ds_name} → {test_ds_name}")
    print(f"  Checkpoint: {ckpt_path}")

    # ── Build test loader ─────────────────────────────────────────────
    from datasets import get_dataset_class
    TestDS   = get_dataset_class(test_ds_name)
    test_ds  = TestDS(test_cfg.dataset, split='test', augment=False)
    test_ldr = DataLoader(test_ds, batch_size=1, shuffle=False,
                          num_workers=train_cfg.training.num_workers)

    # ── Run inference ─────────────────────────────────────────────────
    gt_hrs, pred_hrs = [], []
    per_subject = {}

    with torch.no_grad():
        for batch in tqdm(test_ldr, desc='  Inference'):
            clip    = batch['clip'].to(device)
            hr_gt   = float(batch['hr'])
            subject = batch['subject'][0]

            # TRR: adjust delta for test dataset frame rate
            delta_trr = int(round(
                test_cfg.dataset.fps * 60.0 / max(hr_gt, 40.0)
            ))

            out     = model(clip, hr_est=hr_gt,
                           delta_trr=delta_trr, training=False)
            hr_pred = out['hr_pred']

            gt_hrs.append(hr_gt)
            pred_hrs.append(hr_pred)

            if subject not in per_subject:
                per_subject[subject] = {'gt': [], 'pred': []}
            per_subject[subject]['gt'].append(hr_gt)
            per_subject[subject]['pred'].append(hr_pred)

    # ── Compute metrics ────────────────────────────────────────────────
    gt   = np.array(gt_hrs)
    pred = np.array(pred_hrs)

    hr_metrics  = compute_hr_metrics(gt, pred)
    ba_result   = bland_altman(gt, pred)

    # Per-subject MAE for Wilcoxon test
    subj_maes = [
        np.abs(np.array(v['gt']) - np.array(v['pred'])).mean()
        for v in per_subject.values()
    ]

    print(f"\n  {train_ds_name} → {test_ds_name} Results:")
    print(f"    MAE  : {hr_metrics['mae']:.3f} bpm")
    print(f"    RMSE : {hr_metrics['rmse']:.3f} bpm")
    print(f"    r    : {hr_metrics['r']:.4f}")
    print_bland_altman_summary(ba_result,
                               f"{train_ds_name}→{test_ds_name}")

    results = {
        'train_dataset'   : train_ds_name,
        'test_dataset'    : test_ds_name,
        'n_subjects'      : len(per_subject),
        'n_clips'         : len(gt_hrs),
        'hr_metrics'      : hr_metrics,
        'bland_altman'    : {
            'bias'  : ba_result['bias'],
            'sd'    : ba_result['sd'],
            'loa_hi': ba_result['loa_hi'],
            'loa_lo': ba_result['loa_lo'],
        },
        'per_subject_mae' : {
            'mean': float(np.mean(subj_maes)),
            'std' : float(np.std(subj_maes)),
        },
    }

    if output_path:
        os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
        with open(output_path, 'w') as f:
            json.dump(results, f, indent=2)
        print(f"  Saved to {output_path}")

    return results


def main():
    parser = argparse.ArgumentParser(
        description='PRG-Mamba Cross-Dataset Evaluation'
    )
    parser.add_argument('--train_config', type=str, required=True,
                        help='Config of training dataset')
    parser.add_argument('--test_config',  type=str, required=True,
                        help='Config of test dataset')
    parser.add_argument('--checkpoint',   type=str, required=True,
                        help='Path to trained checkpoint .pth')
    parser.add_argument('--output',       type=str, default=None,
                        help='JSON output path')
    args = parser.parse_args()

    base_cfg    = OmegaConf.load('configs/default.yaml')
    train_cfg   = OmegaConf.merge(
        base_cfg, OmegaConf.load(args.train_config)
    )
    test_cfg    = OmegaConf.merge(
        base_cfg, OmegaConf.load(args.test_config)
    )

    cross_evaluate(train_cfg, test_cfg, args.checkpoint, args.output)


if __name__ == '__main__':
    main()
