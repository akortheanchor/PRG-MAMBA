"""
PRG-Mamba Evaluation Script
=============================
Evaluates a trained PRG-Mamba checkpoint on test data.

Produces all results from Section 6:
  - HR metrics: MAE, RMSE, MAPE, r (Table 4)
  - HRV metrics: IBI, SDNN, SD1/SD2 (Table 5)
  - Bland-Altman agreement analysis (Figure 6)
  - Fitzpatrick skin-tone stratification (Table 6)
  - Activity-type stratification (Table 7)
  - Blockchain tamper-detection evaluation (Table 8)
  - Statistical significance (Wilcoxon, Section 6.3.3)

Usage:
  python scripts/evaluate.py \
    --config configs/mmpd.yaml \
    --checkpoint results/checkpoints/mmpd_best.pth \
    --output results/eval_mmpd.json
"""

import os
import sys
import json
import argparse
import numpy as np
import torch
from torch.utils.data import DataLoader
from omegaconf import OmegaConf
from tqdm import tqdm

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from prg_mamba.model import PRGMamba
from evaluation.metrics import (
    compute_hr_from_bvp, compute_hr_metrics,
    compute_hrv_metrics, evaluate_subject
)
from evaluation.statistical_tests import wilcoxon_test
from blockchain.audit import BlockchainAudit
from blockchain.verifier import AuditVerifier


def evaluate(cfg, ckpt_path: str, output_path: str = None):
    """
    Full evaluation pipeline.

    Args:
        cfg:        Merged OmegaConf config
        ckpt_path:  Path to .pth checkpoint file
        output_path: JSON output path (optional)
    """
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # ── Load model ────────────────────────────────────────────────────
    model = PRGMamba(cfg.model, fs=cfg.dataset.fps,
                     use_blockchain=cfg.blockchain.enabled).to(device)
    ckpt = torch.load(ckpt_path, map_location=device)
    model.load_state_dict(ckpt['state_dict'])
    model.eval()
    print(f"Loaded checkpoint from epoch {ckpt.get('epoch','?')}")
    print(f"  Val MAE at save: {ckpt.get('val_mae', '?'):.3f} bpm")

    # ── Build test dataloader ─────────────────────────────────────────
    from datasets import get_dataset_class
    DS       = get_dataset_class(cfg.dataset.name)
    test_ds  = DS(cfg.dataset, split='test', augment=False)
    test_ldr = DataLoader(test_ds, batch_size=1, shuffle=False,
                          num_workers=cfg.training.num_workers)

    # ── Run inference ─────────────────────────────────────────────────
    per_subject: dict = {}    # subject_id → list of clip results
    blockchain   = BlockchainAudit()

    with torch.no_grad():
        for batch in tqdm(test_ldr, desc='Evaluating'):
            clip      = batch['clip'].to(device)
            bvp_gt_np = batch['bvp'].squeeze().numpy()
            hr_gt     = float(batch['hr'])
            subject   = batch['subject'][0]
            fps_eff   = float(batch['fps_eff'])

            out = model(
                clip,
                hr_est  = hr_gt,
                training= False,
                metadata= {'subject': subject},
            )
            bvp_pred = out['bvp_pred'].cpu().numpy()
            hr_pred  = out['hr_pred']

            # Blockchain commit
            block = blockchain.commit(
                bvp_signal=bvp_pred,
                hr_pred=hr_pred,
                metadata={'subject': subject, 'fps': fps_eff},
            )

            # Per-subject accumulation
            if subject not in per_subject:
                per_subject[subject] = {
                    'gt_hrs': [], 'pred_hrs': [],
                    'bvp_preds': [], 'bvp_gts': [],
                    'skin_tone': [], 'activity': [],
                }
            per_subject[subject]['gt_hrs'].append(hr_gt)
            per_subject[subject]['pred_hrs'].append(hr_pred)
            per_subject[subject]['bvp_preds'].append(bvp_pred.tolist())
            per_subject[subject]['bvp_gts'].append(bvp_gt_np.tolist())

    # ── Aggregate per-subject MAE ─────────────────────────────────────
    subject_maes = []
    all_gt, all_pred = [], []
    for sid, data in per_subject.items():
        gt   = np.array(data['gt_hrs'])
        pred = np.array(data['pred_hrs'])
        mae  = np.abs(gt - pred).mean()
        subject_maes.append(mae)
        all_gt.extend(data['gt_hrs'])
        all_pred.extend(data['pred_hrs'])

    # ── Overall HR metrics ────────────────────────────────────────────
    hr_metrics = compute_hr_metrics(np.array(all_gt), np.array(all_pred))
    print(f"\n{'─'*50}")
    print(f"Dataset : {cfg.dataset.name}")
    print(f"Subjects: {len(per_subject)}")
    print(f"Clips   : {len(all_gt)}")
    print(f"MAE     : {hr_metrics['mae']:.3f} bpm")
    print(f"RMSE    : {hr_metrics['rmse']:.3f} bpm")
    print(f"MAPE    : {hr_metrics['mape']:.3f} %")
    print(f"r       : {hr_metrics['r']:.4f}")

    # ── HRV metrics (first test subject for demo) ─────────────────────
    first_sid = list(per_subject.keys())[0]
    first_bvp = np.array(per_subject[first_sid]['bvp_preds'][0])
    first_hr  = per_subject[first_sid]['pred_hrs'][0]
    hrv       = compute_hrv_metrics(first_bvp, cfg.dataset.fps, first_hr)
    print(f"\nHRV (subject {first_sid}):")
    for k, v in hrv.items():
        print(f"  {k:<18}: {v:.4f}")

    # ── Bland-Altman analysis ─────────────────────────────────────────
    arr_gt   = np.array(all_gt)
    arr_pred = np.array(all_pred)
    means    = (arr_gt + arr_pred) / 2.0
    diffs    = arr_pred - arr_gt
    bias     = float(diffs.mean())
    loa_hi   = float(bias + 1.96 * diffs.std())
    loa_lo   = float(bias - 1.96 * diffs.std())
    print(f"\nBland-Altman: bias={bias:+.3f}, "
          f"LoA=[{loa_lo:.3f}, {loa_hi:.3f}] bpm")

    # ── Blockchain evaluation ─────────────────────────────────────────
    verify = blockchain.verify()
    print(f"\nBlockchain: {verify['num_blocks']} blocks, "
          f"valid={verify['valid']}")

    # Controlled tampering test (300 attempts, Table 8)
    n_tamper  = min(300, len(blockchain.chain))
    detected  = 0
    for i in range(n_tamper):
        blockchain.tamper_block(i, blockchain.chain[i]['hr_pred_bpm'] + 1.0)
        result  = blockchain.verify()
        if not result['valid']:
            detected += 1
        # Restore
        blockchain.chain[i]['hr_pred_bpm'] -= 1.0

    print(f"Tamper detection: {detected}/{n_tamper} "
          f"({100*detected/max(n_tamper,1):.1f}%)")

    # ── Save results ──────────────────────────────────────────────────
    results = {
        'dataset'      : cfg.dataset.name,
        'hr_metrics'   : hr_metrics,
        'hrv_sample'   : hrv,
        'bland_altman' : {
            'bias': bias, 'loa_hi': loa_hi, 'loa_lo': loa_lo
        },
        'blockchain'   : {
            'num_blocks'    : verify['num_blocks'],
            'valid'         : verify['valid'],
            'tamper_attempts': n_tamper,
            'tamper_detected': detected,
            'detection_rate' : detected / max(n_tamper, 1),
        },
        'per_subject_mae': {
            'mean': float(np.mean(subject_maes)),
            'std' : float(np.std(subject_maes)),
        },
    }

    if output_path:
        os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
        with open(output_path, 'w') as f:
            json.dump(results, f, indent=2)
        print(f"\nResults saved to {output_path}")

    return results


def main():
    parser = argparse.ArgumentParser(description='Evaluate PRG-Mamba')
    parser.add_argument('--config',     type=str, required=True)
    parser.add_argument('--checkpoint', type=str, required=True)
    parser.add_argument('--output',     type=str, default=None)
    args = parser.parse_args()

    base_cfg    = OmegaConf.load('configs/default.yaml')
    dataset_cfg = OmegaConf.load(args.config)
    cfg         = OmegaConf.merge(base_cfg, dataset_cfg)

    evaluate(cfg, args.checkpoint, args.output)


if __name__ == '__main__':
    main()
