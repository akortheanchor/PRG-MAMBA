"""
PRG-Mamba Training Script
==========================
Trains PRG-Mamba on a single dataset using the
configuration specified by --config.

Implements the training protocol from Section 5.7:
  - Adam optimiser, lr=1e-4, weight_decay=0.01
  - Cosine-annealed OneCycleLR scheduler
  - Batch size 4, num_workers 4
  - 5 independent runs (different seeds)
  - Convergence: delta=0.01 bpm over patience=5 epochs

Usage:
  python scripts/train.py --config configs/mmpd.yaml
  python scripts/train.py --config configs/pure.yaml --seed 7

Paper reference: PRG-Mamba, Table 6 (Section 5.7)
"""

import os
import sys
import argparse
import random
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torch.optim import Adam
from torch.optim.lr_scheduler import OneCycleLR
from omegaconf import OmegaConf
from tqdm import tqdm
from typing import Dict

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from prg_mamba.model import PRGMamba
from losses.composite import CompositeLoss
from evaluation.metrics import compute_hr_metrics
from evaluation.statistical_tests import wilcoxon_test


def set_seed(seed: int):
    """Fix all random seeds for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark     = False


def build_dataloaders(cfg, octaaug=None):
    """Build train/val/test DataLoaders for the configured dataset."""
    from datasets import get_dataset_class
    DS = get_dataset_class(cfg.dataset.name)

    train_ds = DS(cfg.dataset, split='train', augment=True,  octaaug=octaaug)
    val_ds   = DS(cfg.dataset, split='val',   augment=False, octaaug=None)
    test_ds  = DS(cfg.dataset, split='test',  augment=False, octaaug=None)

    nw = cfg.training.num_workers
    train_loader = DataLoader(train_ds, batch_size=cfg.training.batch_size,
                               shuffle=True,  num_workers=nw, pin_memory=True,
                               drop_last=True)
    val_loader   = DataLoader(val_ds,   batch_size=1, shuffle=False,
                               num_workers=nw, pin_memory=True)
    test_loader  = DataLoader(test_ds,  batch_size=1, shuffle=False,
                               num_workers=nw, pin_memory=True)
    return train_loader, val_loader, test_loader


def train_one_epoch(
    model: PRGMamba,
    loader: DataLoader,
    loss_fn: CompositeLoss,
    optimiser: Adam,
    scheduler: OneCycleLR,
    device: torch.device,
    epoch: int,
) -> Dict[str, float]:
    """Run one training epoch. Returns mean losses."""
    model.train()
    loader.dataset.set_epoch(epoch)

    total = {'total': 0., 'npcc': 0., 'freq': 0., 'hr': 0., 'period': 0.}
    n     = 0

    for batch in tqdm(loader, desc=f'  Train E{epoch:03d}', leave=False):
        clip       = batch['clip'].to(device)         # (1, C, T, H, W)
        bvp_gt     = batch['bvp'].to(device).squeeze()
        hr_gt      = float(batch['hr'])
        delta_trr  = int(batch['delta_trr'])
        fps_eff    = float(batch['fps_eff'])

        optimiser.zero_grad()

        out = model(
            clip,
            hr_est    = hr_gt,
            delta_trr = delta_trr,
            training  = True,
        )

        losses = loss_fn(
            pred_bvp   = out['bvp_pred'],
            gt_bvp     = bvp_gt,
            embeddings = out['fused_emb'],
            hr_est     = hr_gt,
        )

        losses['total'].backward()
        nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
        optimiser.step()
        scheduler.step()

        for k, v in losses.items():
            total[k] += (v.item() if hasattr(v, 'item') else v)
        n += 1

    return {k: v / max(n, 1) for k, v in total.items()}


@torch.no_grad()
def validate(
    model: PRGMamba,
    loader: DataLoader,
    device: torch.device,
) -> Dict[str, float]:
    """Validation pass: compute per-subject MAE."""
    model.eval()
    gt_hrs, pred_hrs = [], []

    for batch in loader:
        clip    = batch['clip'].to(device)
        hr_gt   = float(batch['hr'])
        out     = model(clip, hr_est=hr_gt, training=False)
        gt_hrs.append(hr_gt)
        pred_hrs.append(out['hr_pred'])

    return compute_hr_metrics(np.array(gt_hrs), np.array(pred_hrs))


def train(cfg, seed: int = 42):
    """Full training run for one seed."""
    set_seed(seed)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"\nDevice: {device} | Seed: {seed} | Dataset: {cfg.dataset.name}")

    # Build OctaAug pipeline
    from octaaug.pipeline import OctaAug
    octaaug = OctaAug(cfg.octaaug, fs=cfg.dataset.fps)

    # Build dataloaders
    train_loader, val_loader, test_loader = build_dataloaders(cfg, octaaug)

    # Build model
    model   = PRGMamba(cfg.model, fs=cfg.dataset.fps).to(device)
    n_param = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"  Parameters: {n_param/1e6:.2f}M")

    # Loss and optimiser
    loss_fn = CompositeLoss(
        lambda1=cfg.loss.lambda1,
        lambda2=cfg.loss.lambda2,
        lambda3=cfg.loss.lambda3,
        fs=cfg.dataset.fps,
    )
    optimiser = Adam(
        model.parameters(),
        lr=cfg.training.lr,
        betas=cfg.training.betas,
        weight_decay=cfg.training.weight_decay,
    )
    total_steps = cfg.training.epochs * len(train_loader)
    scheduler   = OneCycleLR(
        optimiser,
        max_lr=cfg.training.max_lr,
        total_steps=total_steps,
        pct_start=0.1,
    )

    # Training loop
    best_mae = float('inf')
    patience = 0
    os.makedirs('results/checkpoints', exist_ok=True)
    ckpt_path = f"results/checkpoints/{cfg.dataset.name.lower()}_seed{seed}.pth"

    for epoch in range(1, cfg.training.epochs + 1):
        train_losses = train_one_epoch(
            model, train_loader, loss_fn, optimiser, scheduler, device, epoch
        )
        val_metrics  = validate(model, val_loader, device)
        val_mae      = val_metrics['mae']

        print(
            f"  E{epoch:03d} | "
            f"L={train_losses['total']:.4f} "
            f"NPCC={train_losses['npcc']:.4f} | "
            f"Val MAE={val_mae:.3f} bpm"
        )

        # Convergence check (Section 5.7, Table 6)
        if best_mae - val_mae > cfg.training.convergence_delta:
            best_mae  = val_mae
            patience  = 0
            torch.save({
                'epoch'     : epoch,
                'state_dict': model.state_dict(),
                'val_mae'   : val_mae,
                'cfg'       : OmegaConf.to_container(cfg),
            }, ckpt_path)
        else:
            patience += 1
            if patience >= cfg.training.convergence_patience:
                print(f"  Converged at epoch {epoch} (patience={patience})")
                break

    # Final test evaluation
    ckpt = torch.load(ckpt_path, map_location=device)
    model.load_state_dict(ckpt['state_dict'])
    test_metrics = validate(model, test_loader, device)
    print(f"\n  Test MAE = {test_metrics['mae']:.3f} bpm | "
          f"RMSE = {test_metrics['rmse']:.3f} | "
          f"r = {test_metrics['r']:.4f}")

    return test_metrics


def main():
    parser = argparse.ArgumentParser(description='Train PRG-Mamba')
    parser.add_argument('--config', type=str, required=True,
                        help='Dataset config YAML (e.g. configs/mmpd.yaml)')
    parser.add_argument('--seed',   type=int, default=42)
    parser.add_argument('--runs',   type=int, default=None,
                        help='Override num_runs from config')
    args = parser.parse_args()

    # Load config: merge dataset config onto default
    base_cfg    = OmegaConf.load('configs/default.yaml')
    dataset_cfg = OmegaConf.load(args.config)
    cfg         = OmegaConf.merge(base_cfg, dataset_cfg)

    num_runs = args.runs or cfg.training.num_runs
    seeds    = [args.seed + i for i in range(num_runs)]

    all_results = []
    for seed in seeds:
        result = train(cfg, seed)
        all_results.append(result)

    # Report mean ± std across runs (Section 5.7)
    if len(all_results) > 1:
        for k in ['mae', 'rmse', 'r']:
            vals = [r[k] for r in all_results]
            print(f"  {k.upper()}: {np.mean(vals):.3f} ± {np.std(vals):.3f}")


if __name__ == '__main__':
    main()
